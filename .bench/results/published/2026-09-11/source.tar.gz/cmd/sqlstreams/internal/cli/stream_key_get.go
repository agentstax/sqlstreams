package cli

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"text/tabwriter"

	"github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/spf13/cobra"
)

func newStreamKeyGetCmd(g *globalFlags) *cobra.Command {
	cmd := &cobra.Command{
		Use:   "get <stream> <key>",
		Short: "Show the key's compaction head",
		Long: `Show the key's compaction head -- the message that currently wins under it.
A key nothing was produced under with compaction enabled has no head and
exits non-zero with SQL0066.`,
		Example: `  sqlstreams stream key get orders.created order-42`,
		Args:    cobra.ExactArgs(2),
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx := cmd.Context()
			streamName, messageKey := args[0], args[1]
			out := cmd.OutOrStdout()

			connection, err := newConnection(ctx, g.databaseURL, g.schema, slog.LevelError)
			if err != nil {
				return err
			}
			defer connection.Close()
			client := connection.client

			head, err := client.Stream[sqlstreams.RawPayload](streamName).Key(messageKey).CompactionHead(ctx)
			if err != nil {
				return translateAdminError(err)
			}

			if g.jsonOutput() {
				writeJSON(out, head)
				return nil
			}

			fmt.Fprintf(out, "%s compaction head for %q on %q\n\n", glyphOK(), messageKey, streamName)
			printStoredMessage(out, head)
			return nil
		},
	}

	return cmd
}

// printStoredMessage is the row's facts one per line, then the payload
// re-indented under its own label.
func printStoredMessage(w io.Writer, head *sqlstreams.StoredMessage[sqlstreams.RawPayload]) {
	tw := tabwriter.NewWriter(w, 0, 0, 3, ' ', 0)
	fmt.Fprintf(tw, "  MessageId\t%d\n", head.Id)
	fmt.Fprintf(tw, "  CreatedAt\t%s\n", timeCell(head.CreatedAt))
	fmt.Fprintf(tw, "  RoutingKey\t%s\n", head.RoutingKey)
	fmt.Fprintf(tw, "  CompactionRank\t%d\n", head.CompactionRank)
	tw.Flush()

	fmt.Fprintln(w, "  Message")
	fmt.Fprintln(w, indentedPayload(*head.Message, "    "))
}

// indentedPayload re-indents the stored JSON under prefix; bytes that do not
// indent (they always should -- the column is JSONB) print as they are.
func indentedPayload(payload sqlstreams.RawPayload, prefix string) string {
	var indented bytes.Buffer
	if err := json.Indent(&indented, payload, prefix, "  "); err != nil {
		return prefix + string(payload)
	}
	return prefix + indented.String()
}

// compactPayload is the stored JSON on one line, for table cells.
func compactPayload(payload sqlstreams.RawPayload) string {
	var compacted bytes.Buffer
	if err := json.Compact(&compacted, payload); err != nil {
		return string(payload)
	}
	return compacted.String()
}
