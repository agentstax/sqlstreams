package cli

import (
	"encoding/json"
	"errors"

	"github.com/agentstax/sqlstreams/pkg/common"
	"github.com/agentstax/sqlstreams/pkg/consume"
	"github.com/agentstax/sqlstreams/pkg/stream"
	"github.com/spf13/cobra"
)

func newConsumerConfigCmd(g *globalFlags) *cobra.Command {
	cmd := &cobra.Command{
		Use:   "config",
		Short: "Read a consumer's config",
		Long: `A consumer's config comes from the cfg your code passes to consumer Register,
and is applied every time that runs. Changing a value means changing that
code and redeploying; this command only reads.

Each consumer kind declares its own keys, so the WORKER column names the row
a value came from and there is no single default to show.

A running consumer instance reads its config when it claims work, so a change takes
effect at its next claim, not live.`,
	}

	cmd.AddCommand(newConsumerConfigGetCmd(g))

	return cmd
}

// messageFieldKey is one field of the message document: the dotted path
// config get prints, and how get reads it back.
type messageFieldKey struct {
	path string
	read func(options *common.MessageOptions) string
}

var messageFieldKeys = []messageFieldKey{
	{
		path: "message.concurrency",
		read: func(options *common.MessageOptions) string {
			return string(options.Concurrency)
		},
	},
	{
		path: "message.timeout",
		read: func(options *common.MessageOptions) string {
			return durationCell(options.Timeout)
		},
	},
	{
		path: "message.retry.max_retries",
		read: func(options *common.MessageOptions) string {
			return intCell(options.Retry.MaxRetries)
		},
	},
	{
		path: "message.retry.base_delay",
		read: func(options *common.MessageOptions) string {
			return durationCell(options.Retry.BaseDelay)
		},
	},
	{
		path: "message.retry.max_delay",
		read: func(options *common.MessageOptions) string {
			return durationCell(options.Retry.MaxDelay)
		},
	},
	{
		path: "message.retry.exponent",
		read: func(options *common.MessageOptions) string {
			return intCell(options.Retry.Exponent)
		},
	},
}

// decodeMessageOptions decodes a worker row's stored message document.
func decodeMessageOptions(value any) (*common.MessageOptions, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return nil, err
	}
	var options common.MessageOptions
	if err := json.Unmarshal(raw, &options); err != nil {
		return nil, err
	}
	// Retry may be absent from the document; field reads assume it isn't
	if options.Retry == nil {
		options.Retry = &common.RetryPolicy{}
	}
	return &options, nil
}

// consumerError maps a consumer config command failure to CLI output.
func consumerError(streamName string, consumerName string, err error) error {
	switch {
	case errors.Is(err, consume.ErrConsumerNotFound):
		return failOp("consumer %q not found on stream %q", consumerName, streamName)
	case errors.Is(err, stream.ErrStreamNotFound):
		return errStreamNotFound(streamName)
	default:
		return translateAdminError(err)
	}
}
