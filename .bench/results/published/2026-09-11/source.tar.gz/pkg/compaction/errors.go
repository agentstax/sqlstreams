package compaction

import (
	"github.com/agentstax/sqlstreams/pkg/common/diagnostic"
)

// ErrCompactionHeadNotFound means no message produced under the key is its
// current compaction head. A lockable row may exist without a head.
//
// Diagnose queries: sqlstreams explain SQL0066
var ErrCompactionHeadNotFound = diagnostic.NewDiagnosticError("SQL0066", diagnostic.RecoveryPermanent,
	"compaction head not found",
	"produce under message key \"{message_key}\" on stream \"{stream}\" with CompactionOptions.Enable set",

	diagnostic.NewDiagnosticQuery("the key's compaction_head row, if one exists", `
SELECT
	compaction_key,
	message_id,
	schema_version,
	compaction_rank
FROM {schema}.compaction_head_{stream_id}
WHERE compaction_key = '{message_key}';`),
	diagnostic.NewDiagnosticQuery("the messages produced under the key -- a NULL compaction_rank never opted into compaction", `
SELECT
	id,
	schema_version,
	compaction_rank,
	created_at
FROM {schema}.message_log_{stream_id}
WHERE message_key = '{message_key}'
ORDER BY id DESC
LIMIT 20;`),
)
