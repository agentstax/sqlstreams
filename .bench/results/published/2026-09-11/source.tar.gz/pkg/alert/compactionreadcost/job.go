package compactionreadcost

import (
	"github.com/agentstax/sqlstreams/pkg/alert"
	alertcontroller "github.com/agentstax/sqlstreams/pkg/alert/controller"
)

var JobName = "alert." + alert.AlertCompactionReadCost.Name

// NewJob builds the schedule the compaction_read_cost alert is evaluated on.
// cfg may be nil or sparse.
func NewJob(cfg *alert.CompactionReadCostAlertConfig) (*alertcontroller.Job, error) {
	if cfg == nil {
		cfg = &alert.CompactionReadCostAlertConfig{}
	}
	cfg.WithDefaults()
	if err := cfg.Validate(); err != nil {
		return nil, err
	}

	data, err := alert.NewJobPayload(cfg.Threshold, cfg.PendingDuration, cfg.MaximumGap, cfg.DisablePending)
	if err != nil {
		return nil, err
	}

	// exclusive so runs never overlap
	return alertcontroller.NewJob(JobName, cfg.ScheduleExpression, data)
}
