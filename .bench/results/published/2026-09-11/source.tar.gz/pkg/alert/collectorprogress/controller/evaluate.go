package controller

import (
	"context"
	"errors"
	"fmt"
	"math"
	"time"

	"github.com/agentstax/sqlstreams/pkg/alert"
	"github.com/agentstax/sqlstreams/pkg/common"
	"github.com/agentstax/sqlstreams/pkg/metric"
	"github.com/agentstax/sqlstreams/pkg/metric/collector"
	"github.com/agentstax/sqlstreams/pkg/worker"
	workercontroller "github.com/agentstax/sqlstreams/pkg/worker/controller"
	"github.com/agentstax/sqlstreams/pkg/worker/manager"
)

// Evaluate compares the latest completion with continuous system-manager lease coverage.
// No measurement or alert is written; MaximumAge 0 uses the collector's declared poll rate.
func (c *CollectorProgressController) Evaluate(ctx context.Context, owner *common.Owner, policy *alert.JobPayload) (*alert.AlertEvaluationSnapshot, error) {
	if err := workercontroller.ValidateOwner(owner, common.OwnerSystem, alert.AlertMetricsCollectorProgress.Name); err != nil {
		return nil, err
	}
	if policy == nil {
		return nil, errors.New("policy must not be nil")
	}
	if err := policy.WithDefaults().Validate(); err != nil {
		return nil, err
	}

	maximumAge, err := c.maximumAge(ctx, owner, policy.MaximumAge)
	if err != nil {
		return nil, err
	}
	completion, err := c.metrics.GetMeasurement(ctx, metric.MetricCollectorCompletedTimestamp.Name)
	if err != nil {
		return nil, err
	}
	declared, err := c.workers.GetWorker(ctx, manager.WorkerManager, owner)
	if err != nil {
		return nil, err
	}
	history, err := c.workers.GetInstanceHistory(ctx, declared.Id, policy.PendingDuration)
	if err != nil {
		return nil, err
	}
	return c.evaluateHistory(owner, completion, history, maximumAge, policy)
}

func (c *CollectorProgressController) maximumAge(ctx context.Context, owner *common.Owner, configured time.Duration) (time.Duration, error) {
	if configured > 0 {
		return configured, nil
	}
	declared, err := c.workers.GetWorker(ctx, collector.WorkerMetricsCollector, owner)
	if err != nil {
		return 0, err
	}
	metadata, err := workercontroller.ParseMetadata[map[string]time.Duration](declared.Metadata)
	if err != nil {
		return 0, err
	}
	pollRate := (*metadata)["poll_rate"]
	if pollRate <= 0 || pollRate > time.Duration(math.MaxInt64)/3 {
		return 0, fmt.Errorf("poll_rate must be in (0, %v], got %v", time.Duration(math.MaxInt64)/3, pollRate)
	}
	return max(2*time.Minute, 3*pollRate), nil
}

func (c *CollectorProgressController) evaluateHistory(owner *common.Owner, completion *common.StoredMessage[metric.Measurement], history *worker.WorkerInstanceHistory, maximumAge time.Duration, policy *alert.JobPayload) (*alert.AlertEvaluationSnapshot, error) {
	current := history.EvaluatedAt
	completedAt, usable := completionTimestamp(completion, current)
	if !usable {
		return alert.NewAlertEvaluationSnapshot(alert.AlertEvaluationStateInsufficientEvidence, nil, &alert.AlertEvaluationSnapshotConfig{
			EvaluatedAt:     current,
			PendingDuration: policy.PendingDuration,
			MaximumAge:      maximumAge,
			DisablePending:  policy.DisablePending,
			Reason:          "collector completion timestamp is unusable or after evaluation time",
		})
	}
	if !completedAt.IsZero() && current.Sub(completedAt) < maximumAge {
		return alert.NewAlertEvaluationSnapshot(alert.AlertEvaluationStateHealthy, nil, &alert.AlertEvaluationSnapshotConfig{
			EvaluatedAt:     current,
			ObservedAt:      completedAt,
			PendingDuration: policy.PendingDuration,
			MaximumAge:      maximumAge,
			DisablePending:  policy.DisablePending,
		})
	}

	// Without current manager coverage, no unhealthy duration can be established.
	managerCoverageStart := continuousLeaseStart(history)
	if managerCoverageStart.IsZero() {
		return alert.NewAlertEvaluationSnapshot(alert.AlertEvaluationStateInsufficientEvidence, nil, &alert.AlertEvaluationSnapshotConfig{
			EvaluatedAt:     current,
			ObservedAt:      completedAt,
			PendingDuration: policy.PendingDuration,
			MaximumAge:      maximumAge,
			DisablePending:  policy.DisablePending,
			Reason:          "no current manager lease coverage",
		})
	}

	// Time before continuous manager coverage, including a shutdown, does not count.
	unhealthySince := managerCoverageStart

	// Only count history inside the window requested for this evaluation.
	historyWindowStart := current.Add(-policy.PendingDuration)
	if historyWindowStart.After(unhealthySince) {
		unhealthySince = historyWindowStart
	}

	// A completed pass stays healthy until its maximum age; that time does not count.
	// Without a completion, count from the coverage/window start above.
	if !completedAt.IsZero() {
		completionOverdueAt := completedAt.Add(maximumAge)
		if completionOverdueAt.After(unhealthySince) {
			unhealthySince = completionOverdueAt
		}
	}
	observedDuration := current.Sub(unhealthySince)

	finding, err := newCollectorProgressAlert(owner, completedAt, maximumAge, current)
	if err != nil {
		return nil, err
	}
	state := alert.AlertEvaluationStateActive
	if !policy.DisablePending && observedDuration < policy.PendingDuration {
		state = alert.AlertEvaluationStatePending
	}
	return alert.NewAlertEvaluationSnapshot(state, finding, &alert.AlertEvaluationSnapshotConfig{
		EvaluatedAt:      current,
		ObservedAt:       completedAt,
		UnhealthySince:   unhealthySince,
		ObservedDuration: observedDuration,
		PendingDuration:  policy.PendingDuration,
		MaximumAge:       maximumAge,
		DisablePending:   policy.DisablePending,
	})
}

// ***************
// *** HELPERS ***
// ***************

// Missing completion is usable absence; malformed or future evidence is not.
func completionTimestamp(completion *common.StoredMessage[metric.Measurement], current time.Time) (time.Time, bool) {
	if completion == nil {
		return time.Time{}, true
	}
	measurement := completion.Message
	if measurement.Name != metric.MetricCollectorCompletedTimestamp.Name ||
		measurement.Kind != metric.MetricKindGauge ||
		measurement.Unit != metric.MetricUnit(metric.MetricCollectorCompletedTimestamp.Unit) {
		return time.Time{}, false
	}
	value := measurement.Value
	if math.IsNaN(value) || value <= 0 || value >= math.MaxInt64 || math.Trunc(value) != value {
		return time.Time{}, false
	}
	completedAt := time.Unix(int64(value), 0)
	if completedAt.After(current) || completion.CreatedAt.After(current) {
		return time.Time{}, false
	}
	return completedAt, true
}

// Instances are ordered by creation time descending; touching leases preserve coverage.
func continuousLeaseStart(history *worker.WorkerInstanceHistory) time.Time {
	var startedAt time.Time
	for _, instance := range history.Instances {
		if startedAt.IsZero() {
			if instance.ExpiresAt.After(history.EvaluatedAt) {
				startedAt = instance.CreatedAt
			}
			continue
		}
		if instance.ExpiresAt.Before(startedAt) {
			continue
		}
		startedAt = instance.CreatedAt
	}
	return startedAt
}
