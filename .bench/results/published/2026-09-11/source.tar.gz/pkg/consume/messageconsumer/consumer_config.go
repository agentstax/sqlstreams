package messageconsumer

import (
	"fmt"
	"time"

	"github.com/agentstax/sqlstreams/pkg/common"
)

// MessageConsumerConfig is the slice of the group's consumer config this
// worker row runs on. pkg/consumer resolves and validates the whole config once,
// then builds this -- so WithDefaults here only backstops a direct caller.
type MessageConsumerConfig struct {
	BatchLimit         int // messages claimed per range
	QueueSize          int // claimed messages buffered ahead of processing -- must be >= BatchLimit
	MessageConcurrency int // messages processed concurrently
	MaxRangeReclaims   int // past this many reclaims a range is POISON -- quarantined into the exception window

	ClaimPollRate           time.Duration
	QueueMargin             time.Duration // lease padding for time a claimed item sits queued before a worker starts on it
	RecordMargin            time.Duration // lease padding for recording success/failure after consumerFunc returns
	TimeoutGrace            time.Duration // scheduling slack for a consumerFunc that DID respect ctx.Done() to unwind before the hard cutoff abandons it
	SlowDispatchThreshold   time.Duration // a delivery dispatch running longer than this logs a warn line with its duration -- 0 disables
	ExceptionInitialBackoff time.Duration // can_run_after delay when an exception row is first written

	InstanceTTL           time.Duration // how long a claimed worker_instance row stays live without a heartbeat renewal
	ConfigRefreshInterval time.Duration // how often the running instance re-reads the group's stored config document

	ShutdownTimeout time.Duration // bounds how long drain waits for in-flight work before open ranges are settled. 0 -> derived at drain from the current MessageMax.Timeout + TimeoutGrace + RecordMargin, so a refreshed ceiling moves the budget with it

	// Message / MessageMin / MessageMax / ConcurrencyOverride resolve each
	// message's own requested options against this group's defaults and bounds.
	Message             *common.MessageOptions
	MessageMin          *common.MessageOptions
	MessageMax          *common.MessageOptions
	ConcurrencyOverride common.ConcurrencyPolicy
}

func (c *MessageConsumerConfig) WithDefaults() *MessageConsumerConfig {
	if c.BatchLimit == 0 {
		c.BatchLimit = 1
	}
	if c.QueueSize == 0 {
		c.QueueSize = c.BatchLimit
	}
	if c.MessageConcurrency == 0 {
		c.MessageConcurrency = 1
	}
	if c.MaxRangeReclaims == 0 {
		c.MaxRangeReclaims = 3
	}
	if c.ClaimPollRate == 0 {
		c.ClaimPollRate = 5 * time.Second
	}
	if c.QueueMargin == 0 {
		c.QueueMargin = 5 * time.Second
	}
	if c.RecordMargin == 0 {
		c.RecordMargin = 2 * time.Second
	}
	if c.TimeoutGrace == 0 {
		c.TimeoutGrace = 100 * time.Millisecond
	}
	if c.ExceptionInitialBackoff == 0 {
		c.ExceptionInitialBackoff = 5 * time.Second
	}
	if c.InstanceTTL == 0 {
		c.InstanceTTL = 30 * time.Second
	}
	if c.ConfigRefreshInterval == 0 {
		c.ConfigRefreshInterval = 30 * time.Second
	}

	c.Message = c.Message.WithDefaults()

	// ceilings must always exist -- lease sizing needs them
	bounds := *c.Message
	bounds.Concurrency = ""
	c.MessageMax = c.MessageMax.Fill(&bounds)

	return c
}

func (c *MessageConsumerConfig) Validate() error {
	if c.BatchLimit < 1 {
		return fmt.Errorf("BatchLimit must be >= 1, got %d", c.BatchLimit)
	}
	if c.QueueSize < c.BatchLimit {
		return fmt.Errorf("QueueSize (%d) must be >= BatchLimit (%d), otherwise the prefetcher can never claim a full batch", c.QueueSize, c.BatchLimit)
	}
	if c.MessageConcurrency < 1 {
		return fmt.Errorf("MessageConcurrency must be >= 1, got %d", c.MessageConcurrency)
	}
	if c.MaxRangeReclaims < 1 {
		return fmt.Errorf("MaxRangeReclaims must be >= 1, got %d", c.MaxRangeReclaims)
	}
	if c.ClaimPollRate <= 0 {
		return fmt.Errorf("ClaimPollRate must be > 0, got %v", c.ClaimPollRate)
	}
	if c.QueueMargin <= 0 {
		return fmt.Errorf("QueueMargin must be > 0, got %v", c.QueueMargin)
	}
	if c.RecordMargin <= 0 {
		return fmt.Errorf("RecordMargin must be > 0, got %v", c.RecordMargin)
	}
	if c.TimeoutGrace <= 0 {
		return fmt.Errorf("TimeoutGrace must be > 0, got %v", c.TimeoutGrace)
	}
	if c.SlowDispatchThreshold < 0 {
		return fmt.Errorf("SlowDispatchThreshold must be >= 0, got %v", c.SlowDispatchThreshold)
	}
	if c.ExceptionInitialBackoff <= 0 {
		return fmt.Errorf("ExceptionInitialBackoff must be > 0, got %v", c.ExceptionInitialBackoff)
	}
	if c.InstanceTTL <= 0 {
		return fmt.Errorf("InstanceTTL must be > 0, got %v", c.InstanceTTL)
	}
	if c.ConfigRefreshInterval <= 0 {
		return fmt.Errorf("ConfigRefreshInterval must be > 0, got %v", c.ConfigRefreshInterval)
	}
	if c.ShutdownTimeout < 0 {
		return fmt.Errorf("ShutdownTimeout must be >= 0, got %v", c.ShutdownTimeout)
	}
	if err := c.Message.Validate(); err != nil {
		return fmt.Errorf("Message: %w", err)
	}
	if err := c.MessageMax.Validate(); err != nil {
		return fmt.Errorf("MessageMax: %w", err)
	}
	return nil
}

func (c *MessageConsumerConfig) resolveMessageOptions(requested *common.MessageOptions) *common.MessageOptions {
	return requested.Fill(c.Message).Clamp(c.MessageMin, c.MessageMax).ResolveConcurrency(c.ConcurrencyOverride)
}

// withMetadata resolves what this run uses: the stored group document --
// whichever process declared it last -- with unset fields resolved to the
// library defaults by the same WithDefaults every declaration resolves
// against.
func (c *MessageConsumerConfig) withMetadata(metadata *MessageConsumerMetadata) *MessageConsumerConfig {
	applied := *c
	applied.Message = metadata.Message
	applied.MessageMin = metadata.MessageMin
	applied.MessageMax = metadata.MessageMax
	applied.ConcurrencyOverride = metadata.ConcurrencyOverride
	applied.ExceptionInitialBackoff = metadata.ExceptionInitialBackoff
	applied.MaxRangeReclaims = metadata.MaxRangeReclaims
	return applied.WithDefaults()
}

// shutdownBudget is one worst-case run at the group's current ceiling plus
// recording its outcome, unless the caller declared a budget of its own.
func (c *MessageConsumerConfig) shutdownBudget() time.Duration {
	if c.ShutdownTimeout != 0 {
		return c.ShutdownTimeout
	}
	return c.MessageMax.Timeout + c.TimeoutGrace + c.RecordMargin
}
