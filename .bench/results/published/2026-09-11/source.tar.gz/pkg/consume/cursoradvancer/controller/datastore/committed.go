package datastore

import (
	"context"
	"fmt"

	"github.com/agentstax/sqlstreams/pkg/stream"
)

// committed is the mark below which every offset is resolved.
//
// Race Condition:
//
//	Because the claiming transaction in FreshClaimMessagesWithCursor advances
//	cursor.claimed AND inserts a lease we must read both cursor and lease
//	tables back in one SELECT, then write separately. Read them inside a single
//	UPDATE instead and postgres hands back the new claimed row but not the new
//	lease, so committed can advance past a range that is still being processed.
//
//	This is due to READ COMMITTED: an UPDATE re-reads the row it modifies at its
//	newest version, but its subqueries keep the snapshot from when the statement
//	began -- so cursor comes back fresh, lease stale.
func (d *CursorAdvancerDatastore) AdvanceCommitted(ctx context.Context, streamId int64, groupId int64) (int64, error) {
	var committed int64
	err := d.DatastoreRetry.Wrap(ctx, func() error {
		var err error
		committed, err = d.advanceCommitted(ctx, streamId, groupId)
		return err
	})
	return committed, err
}

// advanceCommitted needs no transaction across its two statements: a target
// gone stale after the SELECT is only ever too low, and GREATEST makes a
// too-low target a no-op.
func (d *CursorAdvancerDatastore) advanceCommitted(ctx context.Context, streamId int64, groupId int64) (int64, error) {
	// 1. compute the advance target, LEAST of:
	// 		earliest open lease
	// 		earliest unresolved delivery -- 'dead' by definition does not count
	// 		claimed (its caught up to head of log)
	// LEAST ignores NULLs so any/all of those can be absent.
	targetSql := fmt.Sprintf(`
		-- sqlstreams: cursoradvancer.advanceCommitted
		SELECT LEAST(
			(SELECT MIN(low) FROM %[1]s.%[2]s WHERE consumer_group_id = $1),
			(SELECT MIN(message_id) - 1 FROM %[1]s.%[3]s WHERE consumer_group_id = $1 AND status IN ('ready', 'inflight', 'deferred')),
			claimed
		)
		FROM %[1]s.%[4]s
		WHERE consumer_group_id = $1;
	`, d.Datastore.Schema, stream.ClaimLeaseTable(streamId), stream.ExceptionQueueTable(streamId), stream.ConsumerGroupCursorTable(streamId))

	var target int64
	if err := d.Datastore.Pool.QueryRow(ctx, targetSql, groupId).Scan(&target); err != nil {
		return 0, err
	}

	// 2. apply it. GREATEST -> committed only ever moves forward.
	advanceSql := fmt.Sprintf(`
		-- sqlstreams: cursoradvancer.advanceCommitted
		UPDATE %[1]s.%[2]s
		SET committed = GREATEST(committed, $2)
		WHERE consumer_group_id = $1
		RETURNING committed;
	`, d.Datastore.Schema, stream.ConsumerGroupCursorTable(streamId))

	var committed int64
	err := d.Datastore.Pool.QueryRow(ctx, advanceSql, groupId, target).Scan(&committed)
	return committed, err
}
