package consume

import "fmt"

// CursorPositionKind names where a new group's cursor starts.
type CursorPositionKind string

const (
	// CursorPositionBeginning is the zero value: the oldest retained message.
	CursorPositionBeginning CursorPositionKind = ""
	// CursorPositionHead is MAX(id) of the message log when the cursor row is
	// written; a produce with a lower id that commits later is never read.
	CursorPositionHead CursorPositionKind = "head"
)

func (k CursorPositionKind) Validate() error {
	switch k {
	case CursorPositionBeginning, CursorPositionHead:
		return nil
	default:
		return fmt.Errorf("must be one of %q, %q, got %q", CursorPositionBeginning, CursorPositionHead, k)
	}
}

// CursorPosition is a place in a stream's message log a group's cursor is set
// to -- by Register for a group that has no cursor row yet.
type CursorPosition struct {
	Kind CursorPositionKind
}

// Beginning places a new group's cursor at the oldest retained message, so
// it reads history before live traffic. The default.
func Beginning() CursorPosition {
	return CursorPosition{Kind: CursorPositionBeginning}
}

// Head places a new group's cursor at the log's MAX(id) when its row is
// written, so it reads only messages produced after that.
func Head() CursorPosition {
	return CursorPosition{Kind: CursorPositionHead}
}
