package controller

import (
	"context"
	"errors"
	"fmt"
	"slices"
	"strings"
	"time"

	"github.com/agentstax/sqlstreams/pkg/common"
	"github.com/agentstax/sqlstreams/pkg/consume"
	"github.com/agentstax/sqlstreams/pkg/consume/controller/datastore"
)

// DeclareBindings states the group's full binding set -- no patterns = the
// whole stream, '*' in a pattern matches any run of characters.
// declaredAt is when the declarer first stated the set, fixed across its
// retries; callers retry on BindingWaiting.
func (c *ConsumeController) DeclareBindings(ctx context.Context, streamId int64, groupId int64, patterns []string, declaredAt time.Time) (consume.BindingOutcome, error) {
	if streamId <= 0 {
		return "", fmt.Errorf("streamId must be > 0, got %d", streamId)
	}
	if groupId <= 0 {
		return "", fmt.Errorf("groupId must be > 0, got %d", groupId)
	}
	if declaredAt.IsZero() {
		return "", errors.New("declaredAt is required")
	}
	if slices.Contains(patterns, "") {
		return "", errors.New("patterns must not contain an empty pattern")
	}

	declared := normalizePatterns(patterns)
	return c.datastore.DeclareBindings(ctx, streamId, groupId, declared, common.ProcessIdentity, declaredAt)
}

// GetBinding returns the group's effective declaration -- its
// newest installed row -- or nil when the group never installed a set.
func (c *ConsumeController) GetBinding(ctx context.Context, streamId int64, groupId int64) (*consume.Binding, error) {
	if streamId <= 0 {
		return nil, fmt.Errorf("streamId must be > 0, got %d", streamId)
	}
	if groupId <= 0 {
		return nil, fmt.Errorf("groupId must be > 0, got %d", groupId)
	}

	data, err := c.datastore.ListGroupBindingConfigLog(ctx, streamId, groupId)
	if err != nil {
		return nil, err
	}
	effective, found := datastore.NewestInstalledDeclaration(data)
	if !found {
		return nil, nil
	}
	return toBinding(effective), nil
}

// ListBindings returns every group's effective declaration followed by
// its still-waiting declarers, ordered by stream then group.
func (c *ConsumeController) ListBindings(ctx context.Context) ([]*consume.Binding, error) {
	data, err := c.datastore.ListBindingConfigLog(ctx)
	if err != nil {
		return nil, err
	}

	var declarations []*consume.Binding
	for _, rows := range groupByConsumerGroup(data) {
		effective, found := datastore.NewestInstalledDeclaration(rows)
		if !found {
			continue
		}
		declarations = append(declarations, toBinding(effective))
		for _, waiter := range openWaiters(rows, effective) {
			declarations = append(declarations, toBinding(&waiter))
		}
	}

	// stable keeps each group's effective row ahead of its waiters
	slices.SortStableFunc(declarations, compareBindings)
	return declarations, nil
}

// ***************
// *** HELPERS ***
// ***************

// normalizePatterns sorts and deduplicates -- the datastore compares sets
// element-wise. Always returns a non-nil slice; an empty set is a stored
// value, not NULL.
func normalizePatterns(patterns []string) []string {
	normalized := make([]string, 0, len(patterns))
	normalized = append(normalized, patterns...)
	slices.Sort(normalized)
	return slices.Compact(normalized)
}

func groupByConsumerGroup(rows []datastore.BindingConfigLogRow) map[int64][]datastore.BindingConfigLogRow {
	groups := make(map[int64][]datastore.BindingConfigLogRow)
	for _, row := range rows {
		groups[row.ConsumerGroupId] = append(groups[row.ConsumerGroupId], row)
	}
	return groups
}

// openWaiters finds the waiting rows whose declarer is still blocked.
func openWaiters(rows []datastore.BindingConfigLogRow, effective *datastore.BindingConfigLogRow) []datastore.BindingConfigLogRow {
	var waiters []datastore.BindingConfigLogRow
	for i := range rows {
		row := &rows[i]
		if row.Status != datastore.BindingConfigLogWaiting {
			continue
		}
		if declarerInstalledAfter(row, rows) {
			continue
		}
		if slices.Equal(row.Patterns, effective.Patterns) {
			continue
		}
		waiters = append(waiters, rows[i])
	}
	return waiters
}

// declarerInstalledAfter reports whether the waiting row's declarer went on
// to install -- an ended wait leaves its waiting row behind.
func declarerInstalledAfter(waiting *datastore.BindingConfigLogRow, rows []datastore.BindingConfigLogRow) bool {
	for i := range rows {
		if rows[i].Status == datastore.BindingConfigLogInstalled &&
			rows[i].DeclaredBy == waiting.DeclaredBy &&
			rows[i].Id > waiting.Id {
			return true
		}
	}
	return false
}

func compareBindings(left *consume.Binding, right *consume.Binding) int {
	if c := strings.Compare(left.StreamName, right.StreamName); c != 0 {
		return c
	}
	return strings.Compare(left.ConsumerGroupName, right.ConsumerGroupName)
}
