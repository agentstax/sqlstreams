package benchmark

import (
	"testing"
	"time"

	"github.com/agentstax/sqlstreams/.bench/reliability/checker/datastore"
	"github.com/agentstax/sqlstreams/.bench/reliability/record"
	"github.com/agentstax/sqlstreams/.tests/integration/postgres"
)

func newProgressDatastore(t testing.TB, rows []record.ProgressRecord) *datastore.CheckerDatastore {
	t.Helper()
	database := postgres.Start(t)
	checker, err := datastore.NewCheckerDatastore(database.Pool, &datastore.CheckerDatastoreConfig{DisableMessageRecording: true})
	if err != nil {
		t.Fatal(err)
	}
	if err := checker.CreateTables(t.Context()); err != nil {
		t.Fatal(err)
	}
	directory := t.TempDir()
	writer, err := record.NewWriter(directory, "producer", record.FileKindProgress)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { writer.Close() })
	for _, row := range rows {
		if err := writer.Write(row); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := checker.LoadProgress(t.Context(), directory); err != nil {
		t.Fatal(err)
	}
	return checker
}

func TestProgressRatesUseEachProcessesObservedSpan(t *testing.T) {
	// setup
	start := time.Date(2026, 9, 11, 0, 0, 0, 0, time.UTC)
	checker := newProgressDatastore(t, []record.ProgressRecord{
		{At: start, Process: "p1", Stream: "orders", Committed: 100},
		{At: start.Add(10 * time.Second), Process: "p1", Stream: "orders", Committed: 1100, Rejected: 1},
		{At: start.Add(2 * time.Second), Process: "p2", Stream: "orders", Committed: 50},
		{At: start.Add(8 * time.Second), Process: "p2", Stream: "orders", Committed: 1250, Unknown: 2},
		{At: start, Process: "c1", Stream: "orders", Group: "processor", Success: 100},
		{At: start.Add(10 * time.Second), Process: "c1", Stream: "orders", Group: "processor", Success: 3100, Error: 4},
	})

	// test
	produced, produceErr := checker.ReadProducedRate(t.Context(), start, start.Add(10*time.Second), "orders")
	consumed, consumeErr := checker.ReadConsumedRate(t.Context(), start, start.Add(10*time.Second))
	failures, failuresErr := checker.CountErrors(t.Context())

	// verify
	if produceErr != nil || produced != 300 {
		t.Errorf("ReadProducedRate(orders) = %v, %v, want 300, nil", produced, produceErr)
	}
	if consumeErr != nil || consumed != 300 {
		t.Errorf("ReadConsumedRate(10s) = %v, %v, want 300, nil", consumed, consumeErr)
	}
	if failuresErr != nil || failures.Count != 7 {
		t.Errorf("CountErrors(cumulative snapshots) = %+v, %v, want count 7, nil", failures, failuresErr)
	}
}

func TestProgressRejectsAnIncompleteProcessWindow(t *testing.T) {
	// setup
	start := time.Date(2026, 9, 11, 0, 0, 0, 0, time.UTC)
	checker := newProgressDatastore(t, []record.ProgressRecord{
		{At: start, Process: "p1", Stream: "orders", Committed: 100},
		{At: start.Add(time.Second), Process: "p1", Stream: "orders", Committed: 200},
		{At: start, Process: "p2", Stream: "orders", Committed: 100},
	})

	// test
	measured, err := checker.ReadProducedRate(t.Context(), start, start.Add(time.Second), "orders")

	// verify
	if err == nil {
		t.Errorf("ReadProducedRate(incomplete p2) = %v, nil, want an error", measured)
	}
}

func TestProgressRejectsCounterResets(t *testing.T) {
	// setup
	start := time.Date(2026, 9, 11, 0, 0, 0, 0, time.UTC)
	checker := newProgressDatastore(t, []record.ProgressRecord{
		{At: start, Process: "p1", Stream: "orders", Committed: 100},
		{At: start.Add(time.Second), Process: "p1", Stream: "orders", Committed: 200},
		{At: start.Add(2 * time.Second), Process: "p1", Stream: "orders", Committed: 50},
	})

	// test
	measured, err := checker.ReadProducedRate(t.Context(), start, start.Add(2*time.Second), "orders")

	// verify
	if err == nil {
		t.Errorf("ReadProducedRate(reset p1) = %v, nil, want an error", measured)
	}
}
