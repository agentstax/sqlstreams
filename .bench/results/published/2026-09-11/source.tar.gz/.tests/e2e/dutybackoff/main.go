// Command dutybackoff proves a consistently-failing worker backs off
// instead of ticking at full poll rate forever.
//
// Renames a stream's message_log_<id> table out from under a running janitor
// worker, so every sweep fails 42P01. Watches the claimed worker_instance's
// `attempts` streak climb and the gap between failures grow -- small at
// first, capped at SweepRetry's MaxDelay -- then renames the table back and
// confirms the next successful sweep resets attempts to 0.
package main

import (
	"context"
	"fmt"
	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	"github.com/agentstax/sqlstreams/pkg/stream"
	"os"
	"time"

	iCommon "github.com/agentstax/sqlstreams/pkg/common"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	metricscontroller "github.com/agentstax/sqlstreams/pkg/metric/controller"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/agentstax/sqlstreams/pkg/stream/janitor"
	workercontroller "github.com/agentstax/sqlstreams/pkg/worker/controller"
)

const (
	pollRate    = 50 * time.Millisecond
	backoffBase = 300 * time.Millisecond
	backoffMax  = 1500 * time.Millisecond
)

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName := fmt.Sprintf("dutybackoff.%d", time.Now().UnixNano())
	// retention on: the sweep's drop pass reads message_log's head every tick,
	// which is the read the rename below breaks
	tp, err := client.Stream[sqlstreams.RawPayload](streamName).Register(ctx, &sqlstreams.StreamConfig{RetentionTTL: time.Hour})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[sqlstreams.RawPayload](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	janitorProvisioner, err := janitor.NewJanitorProvisioner(ds, &janitor.JanitorConfig{
		SweepRetry: &iCommon.RetryPolicy{BaseDelay: backoffBase, MaxDelay: backoffMax},
	}, ds.Logger)
	common.Must(err)
	workers, err := workercontroller.NewWorkerController(ds, ds.Logger)
	common.Must(err)

	// RegisterStream already declared the janitor row -- claim it directly with
	// the e2e test's own fast tick
	owner, err := iCommon.NewStreamOwner(tp.SystemId, tp.Id, tp.Name)
	common.Must(err)
	row, err := workers.GetWorker(ctx, janitor.WorkerStreamJanitor, owner)
	common.Must(err)
	row.Metadata = map[string]any{
		"poll_rate":        int64(pollRate),
		"sweep_batch_size": 1000,
	}
	execution, err := janitorProvisioner.Provision(ctx, row)
	common.Must(err)
	if execution == nil {
		common.Die("janitor declined the instance -- is another claimant running?")
	}

	runCtx, cancel := context.WithCancel(ctx)
	done := make(chan error, 1)
	go func() { done <- execution.Run(runCtx) }()

	table := fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id))
	// RENAME TO names the new table inside the old one's schema, so it is bare
	hidden := stream.MessageLogTable(tp.Id) + "_hidden"

	step("breaking the janitor: renaming its message_log table away")
	exec(ctx, ds, fmt.Sprintf(`ALTER TABLE %s RENAME TO %s`, table, hidden))

	step("watching attempts climb, the gap between failures growing but capped at SweepRetry's MaxDelay")
	type sample struct {
		attempts int
		at       time.Duration
	}
	start := time.Now()
	var samples []sample
	deadline := start.Add(15 * time.Second)
	for time.Now().Before(deadline) {
		attempts := scalarInt(ctx, ds, fmt.Sprintf(`SELECT attempts FROM %s.worker_instance WHERE worker_id=$1`, ds.Schema), row.Id)
		if len(samples) == 0 || attempts != samples[len(samples)-1].attempts {
			samples = append(samples, sample{attempts, time.Since(start)})
			fmt.Printf("  attempts=%d at %v\n", attempts, time.Since(start).Round(time.Millisecond))
		}
		if attempts >= 5 {
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	if len(samples) < 6 {
		common.Die(fmt.Sprintf("expected attempts to climb to at least 5, got samples: %+v", samples))
	}

	firstGap := samples[2].at - samples[1].at
	lastGap := samples[len(samples)-1].at - samples[len(samples)-2].at
	fmt.Printf("  ✓ first gap %v, last gap %v (cap %v)\n", firstGap, lastGap, backoffMax)
	if firstGap >= backoffBase*3 {
		common.Die(fmt.Sprintf("first backoff gap %v looked capped already, want close to SweepRetry's BaseDelay (%v)", firstGap, backoffBase))
	}
	if lastGap <= firstGap {
		common.Die(fmt.Sprintf("backoff gap didn't grow: first=%v last=%v", firstGap, lastGap))
	}
	if lastGap > backoffMax+pollRate*4 {
		common.Die(fmt.Sprintf("backoff gap %v exceeded SweepRetry's MaxDelay (%v) by more than jitter/poll slack", lastGap, backoffMax))
	}

	step("confirming WorkerSnapshots surfaces the failing streak")
	metricController, err := metricscontroller.NewMetricsController(ds, ds.Logger)
	common.Must(err)
	snapshots, err := metricController.WorkerSnapshots(ctx)
	common.Must(err)
	found := false
	for _, s := range snapshots {
		if s.Owner.Name == streamName && s.Name == janitor.WorkerStreamJanitor {
			found = true
			if s.Attempts == 0 {
				common.Die("expected WorkerSnapshot.Attempts > 0 for the failing janitor")
			}
			fmt.Printf("  ✓ WorkerSnapshot: status=%s attempts=%d\n", s.Status, s.Attempts)
		}
	}
	if !found {
		common.Die("janitor worker not found in WorkerSnapshots")
	}

	step("healing: renaming the table back and waiting for attempts to reset")
	exec(ctx, ds, fmt.Sprintf(`ALTER TABLE %s.%s RENAME TO %s`, ds.Schema, hidden, stream.MessageLogTable(tp.Id)))

	deadline = time.Now().Add(10 * time.Second)
	var final int
	for time.Now().Before(deadline) {
		final = scalarInt(ctx, ds, fmt.Sprintf(`SELECT attempts FROM %s.worker_instance WHERE worker_id=$1`, ds.Schema), row.Id)
		if final == 0 {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if final != 0 {
		common.Die(fmt.Sprintf("expected attempts to reset to 0 after recovery, got %d", final))
	}
	fmt.Println("  ✓ attempts reset to 0 after a successful sweep")

	cancel()
	common.Must(<-done)

	fmt.Println("\n✅ DUTY BACKOFF E2E TEST PASSED")
	return nil
}

func exec(ctx context.Context, ds *iDatastore.PostgresDatastore, sql string) {
	_, err := ds.Pool.Exec(ctx, sql)
	common.Must(err)
}

func scalarInt(ctx context.Context, ds *iDatastore.PostgresDatastore, q string, args ...any) int {
	var v int
	common.Must(ds.Pool.QueryRow(ctx, q, args...).Scan(&v))
	return v
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
