package main

// CompactionRank e2e test: proves the (rank, id) winner rule live against a real
// database -- the claims Chunk 1/2 make about rank but can't verify without
// Postgres actually evaluating the row comparison.
//
// Registers its own stream (destroyed on exit), self-seeds, fully
// self-contained.
//
// Confirms, in order:
//   - a rank-pinned key ignores every normal-rank update that arrives after
//     it, even at a higher id -- the pin holds until something >= its rank
//     arrives.
//   - a -1 backfill write never beats a live write at the default rank 0,
//     regardless of which one arrives (and lands the higher id) first -- the
//     bridge's exact interleaving, proven both orderings.
//   - every losing row (pinned-over, backfilled) stays physically present in
//     message_log but never comes back on a claim.

import (
	"context"
	"fmt"
	"os"
	"time"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	"github.com/agentstax/sqlstreams/pkg/consume"
	consumecontroller "github.com/agentstax/sqlstreams/pkg/consume/controller"
	messageconsumercontroller "github.com/agentstax/sqlstreams/pkg/consume/messageconsumer/controller"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/agentstax/sqlstreams/pkg/stream"
)

const group = "phase14a.compactionrank"

// RankedRecord is this e2e test's own payload shape -- Label exists purely to make
// the printed claim output readable.
type RankedRecord struct {
	Key   string `json:"key"`
	Label string `json:"label"`
}

func (RankedRecord) SchemaVersion() int { return 1 }

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName := fmt.Sprintf("phase14a.compactionrank.%d", time.Now().UnixNano())
	tp, err := client.Stream[sqlstreams.RawPayload](streamName).Register(ctx, &sqlstreams.StreamConfig{})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[sqlstreams.RawPayload](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	cd, err := consumecontroller.NewConsumeController(ds, ds.Logger)
	common.Must(err)
	messageConsumers, err := messageconsumercontroller.NewMessageConsumerGroupController(ds, ds.Logger)
	common.Must(err)
	wpInstance, err := client.Stream[RankedRecord](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)
	groupId := mustGroupID(cd.RegisterGroup(ctx, tp.Id, group, consume.Beginning()))

	const lease = 5 * time.Second
	const maxRangeReclaims = 3 // never exhausted in this e2e test -- no crashes/reclaims here

	// ===== pinning: a high rank ignores every normal-rank update after it (ids 1-4) =====
	step("user:1 gets a normal write, then a rank-100 pin, then two MORE normal writes")
	publish(ctx, wpInstance, "user:1", "v1-normal", 0) // id 1
	publish(ctx, wpInstance, "user:1", "v2-PIN", 100)  // id 2 <- pinned winner
	publish(ctx, wpInstance, "user:1", "v3-normal", 0) // id 3, higher id, still loses to the pin
	publish(ctx, wpInstance, "user:1", "v4-normal", 0) // id 4, higher id still, also loses

	assertInt("compaction_head still points at the pin despite two higher-id normal writes after it", headID(ctx, ds, tp.Id, "user:1"), 2)

	claim, err := messageConsumers.ClaimMessagesWithCursor(ctx, tp.Id, groupId, 1, 10, maxRangeReclaims, lease, stream.DeliveryLogModeFailures)
	common.Must(err)
	if claim == nil {
		common.Die("expected a fresh claim, got nil")
	}
	assertIDs("only the pinned row comes back for user:1", ids(claim.Messages), []int64{2})
	common.Must(messageConsumers.Commit(ctx, tp.Id, groupId, claim.Lease.Token, nil, 5*time.Second, stream.DeliveryLogModeFailures))
	assertInt("v1/v3/v4 still physically exist -- compaction filters, never deletes", rowCount(ctx, ds, tp.Id), 4)

	// ===== the bridge interleaving: -1 never beats 0, either arrival order (ids 5-8) =====
	step("live (rank 0) THEN backfill (rank -1) for user:2 -- backfill's higher id still loses")
	publish(ctx, wpInstance, "user:2", "live", 0)      // id 5 <- stays the winner
	publish(ctx, wpInstance, "user:2", "backfill", -1) // id 6, higher id, rank -1 loses to rank 0
	assertInt("compaction_head still points at the live write, not the higher-id backfill", headID(ctx, ds, tp.Id, "user:2"), 5)

	step("backfill (rank -1) THEN live (rank 0) for user:3 -- live wins as always")
	publish(ctx, wpInstance, "user:3", "backfill", -1) // id 7
	publish(ctx, wpInstance, "user:3", "live", 0)      // id 8 <- wins, same as any normal update would
	assertInt("compaction_head points at the live write", headID(ctx, ds, tp.Id, "user:3"), 8)

	claim, err = messageConsumers.ClaimMessagesWithCursor(ctx, tp.Id, groupId, 1, 10, maxRangeReclaims, lease, stream.DeliveryLogModeFailures)
	common.Must(err)
	if claim == nil {
		common.Die("expected a fresh claim, got nil")
	}
	assertIDs("only the two live-rank winners come back, neither backfill", ids(claim.Messages), []int64{5, 8})
	common.Must(messageConsumers.Commit(ctx, tp.Id, groupId, claim.Lease.Token, nil, 5*time.Second, stream.DeliveryLogModeFailures))

	step("both backfill rows still physically exist, just never claimed")
	assertTrue("user:2's backfill row (id 6) still exists", rowExists(ctx, ds, tp.Id, 6))
	assertTrue("user:3's backfill row (id 7) still exists", rowExists(ctx, ds, tp.Id, 7))
	assertInt("all 8 rows still physically present", rowCount(ctx, ds, tp.Id), 8)

	fmt.Println("\n✅ COMPACTION RANK E2E TEST PASSED")
	fmt.Println("   a pin holds against every normal-rank update after it -> a -1 backfill never")
	fmt.Println("   beats a 0 live write regardless of which arrives first -> every losing row stays")
	fmt.Println("   physically present, just never claimed.")
	return nil
}

// ---- helpers ----

func publish(ctx context.Context, wpInstance *sqlstreams.ProducerInstance[RankedRecord], key, label string, rank int64) {
	_, err := wpInstance.ProduceFunc(ctx, func(ctx context.Context, tx sqlstreams.Tx) (*RankedRecord, error) {
		return &RankedRecord{Key: key, Label: label}, nil
	}, &sqlstreams.ProduceOptions{MessageKey: key, Compaction: &sqlstreams.CompactionOptions{Enable: true, Rank: rank}})
	common.Must(err)
}

func headID(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64, key string) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT message_id FROM %s.%s WHERE compaction_key=$1;`, ds.Schema, stream.CompactionHeadTable(streamId)), key)
}

func rowCount(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT count(*) FROM %s.%s`, ds.Schema, stream.MessageLogTable(streamId)))
}

func rowExists(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId, id int64) bool {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT count(*) FROM %s.%s WHERE id=$1`, ds.Schema, stream.MessageLogTable(streamId)), id) == 1
}

func scalar(ctx context.Context, ds *iDatastore.PostgresDatastore, q string, args ...any) int64 {
	var v int64
	common.Must(ds.Pool.QueryRow(ctx, q, args...).Scan(&v))
	return v
}

func ids(msgs []messageconsumercontroller.Message) []int64 {
	out := make([]int64, len(msgs))
	for i, m := range msgs {
		out[i] = m.Id
	}
	return out
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
func assertInt(label string, got, want int64) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", label, got, want))
	}
	fmt.Printf("  ✓ %s (%d)\n", label, got)
}
func assertIDs(label string, got, want []int64) {
	if len(got) != len(want) {
		common.Die(fmt.Sprintf("%s: got %v, want %v", label, got, want))
	}
	for i := range got {
		if got[i] != want[i] {
			common.Die(fmt.Sprintf("%s: got %v, want %v", label, got, want))
		}
	}
	fmt.Printf("  ✓ %s %v\n", label, got)
}
func assertTrue(label string, cond bool) {
	if !cond {
		common.Die(fmt.Sprintf("%s: got false, want true", label))
	}
	fmt.Printf("  ✓ %s\n", label)
}

func mustGroupID(g *consume.Consumer, err error) int64 { common.Must(err); return g.Id }
