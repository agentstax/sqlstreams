// Command schema proves a schema is one SQLStreams installation: two clients
// on two schemas in one database each register a stream under the same name
// and see only their own.
//
// Sections:
//  1. isolation -- both schemas hold their own full table set, the same stream
//     name registers in each with its own id, and each client lists only its
//     own streams
//  2. independence -- a message produced on one schema is invisible to the
//     other, destroying a stream on one leaves the other's standing, and a
//     caller's own CREATE inside InTransaction lands in the caller's schema
//     rather than sqlstreams's, because the pool sets no search_path [0632]
//  3. absence -- a client pointed at a schema nobody registered reads an
//     absence rather than the neighbouring schema's rows: Get is (nil, nil),
//     every other verb raises ErrStreamNotFound. Holds with a whole
//     installation standing in public, the schema every search_path ends
//     with -- sqlstreams's SQL names its own schema, so there is nothing to
//     fall through to
//  4. locks -- a register held up on one schema does not hold up the same
//     register on the other, and every key carries sqlstreams's namespace
package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"time"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	iCommon "github.com/agentstax/sqlstreams/pkg/common"
	"github.com/agentstax/sqlstreams/pkg/common/logging"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/agentstax/sqlstreams/pkg/stream"
)

// testMessage is the payload both schemas produce.
type testMessage struct {
	Value string
}

func (testMessage) SchemaVersion() int { return 1 }

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	// two schemas, not two databases -- the point is that one database holds
	// both installations and neither can see the other
	runId := time.Now().UnixNano()
	leftSchema := fmt.Sprintf("schema_left_%d", runId)
	rightSchema := fmt.Sprintf("schema_right_%d", runId)

	// Each installation selects its schema from the same base settings.
	shared := &sqlstreams.ClientConfig{AllowDestroy: true}
	left, leftDs := openClient(ctx, leftSchema, shared)
	defer leftDs.Pool.Close()
	right, rightDs := openClient(ctx, rightSchema, shared)
	defer rightDs.Pool.Close()
	defer dropSchemas(ctx, leftDs, leftSchema, rightSchema)

	common.Must(left.System().Register(ctx, nil))
	common.Must(right.System().Register(ctx, nil))

	fmt.Println("=== 1. isolation ===")

	leftTables := tableCount(ctx, leftDs, leftSchema)
	rightTables := tableCount(ctx, rightDs, rightSchema)
	if leftTables == 0 || leftTables != rightTables {
		common.Die(fmt.Sprintf("each schema should hold its own full table set, got left %d right %d", leftTables, rightTables))
	}
	fmt.Printf("   ✅ both schemas hold their own %d tables\n", leftTables)

	// the same name in both -- a name is unique per installation, not per database
	const sharedName = "schema.orders"
	leftStream, err := left.Stream[testMessage](sharedName).Register(ctx, nil)
	common.Must(err)
	rightStream, err := right.Stream[testMessage](sharedName).Register(ctx, nil)
	common.Must(err)
	fmt.Printf("   ✅ %q registered in both, each numbered by its own schema's sequence: left id %d, right id %d\n", sharedName, leftStream.Id, rightStream.Id)

	leftStreams, err := left.Streams(ctx)
	common.Must(err)
	rightStreams, err := right.Streams(ctx)
	common.Must(err)
	if countNamed(leftStreams, sharedName) != 1 || countNamed(rightStreams, sharedName) != 1 {
		common.Die("each client should list its own stream exactly once")
	}
	if len(leftStreams) != len(rightStreams) {
		common.Die(fmt.Sprintf("neither client should see the other's streams, got left %d right %d", len(leftStreams), len(rightStreams)))
	}
	fmt.Printf("   ✅ each client lists %d streams -- its own, not the other's\n", len(leftStreams))

	leftBound, rightBound := boundSchemas(leftDs.Logger), boundSchemas(rightDs.Logger)
	if len(leftBound) != 1 || leftBound[0] != leftSchema || len(rightBound) != 1 || rightBound[0] != rightSchema {
		common.Die(fmt.Sprintf("each datastore should bind only its own schema, got left %v right %v", leftBound, rightBound))
	}
	fmt.Printf("   ✅ every line each datastore logs names one schema -- %q and %q\n", leftBound[0], rightBound[0])

	fmt.Println("\n=== 2. independence ===")

	leftProducer, err := left.Stream[testMessage](sharedName).Producer().Register(ctx, nil)
	common.Must(err)
	_, err = leftProducer.Produce(ctx, &testMessage{Value: "left only"}, nil)
	common.Must(err)

	leftCount := messageCount(ctx, leftDs, leftSchema, leftStream.Id)
	rightCount := messageCount(ctx, rightDs, rightSchema, rightStream.Id)
	if leftCount != 1 || rightCount != 0 {
		common.Die(fmt.Sprintf("a produce on one schema must not reach the other, got left %d right %d", leftCount, rightCount))
	}
	fmt.Printf("   ✅ one produce on left: left holds %d, right holds %d\n", leftCount, rightCount)

	// a caller's own statement inside InTransaction runs on sqlstreams's pool, and
	// the pool sets no search_path [0632] -- so an unqualified CREATE lands
	// where the caller's connection puts it, not inside sqlstreams's schema
	const callerTable = "schema_caller_orders"
	common.Must(left.InTransaction(ctx, func(ctx context.Context, tx sqlstreams.Tx) error {
		_, err := tx.Exec(ctx, `CREATE TABLE IF NOT EXISTS `+callerTable+` (id BIGINT);`)
		return err
	}))
	var landedIn string
	common.Must(leftDs.Pool.QueryRow(ctx,
		`SELECT schemaname FROM pg_tables WHERE tablename = $1;`, callerTable).Scan(&landedIn))
	defer func() {
		_, err := leftDs.Pool.Exec(ctx, `DROP TABLE IF EXISTS `+landedIn+`.`+callerTable+`;`)
		common.Must(err)
	}()
	if landedIn == leftSchema {
		common.Die("a caller's own CREATE inside InTransaction must not land in sqlstreams's schema, got " + landedIn)
	}
	fmt.Printf("   ✅ a caller's CREATE inside InTransaction lands in %q, not sqlstreams's %q\n", landedIn, leftSchema)

	common.Must(left.Stream[testMessage](sharedName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	if _, err := right.Stream[testMessage](sharedName).Get(ctx); err != nil {
		common.Die("destroying the left stream must leave the right one readable: " + err.Error())
	}
	fmt.Println("   ✅ destroying left's stream leaves right's standing")

	fmt.Println("\n=== 3. absence ===")

	emptySchema := fmt.Sprintf("schema_empty_%d", runId)
	empty, emptyDs := openClient(ctx, emptySchema, shared)
	defer emptyDs.Pool.Close()

	// the schema does not exist, and every sqlstreams statement names it [0631],
	// so the catalog read raises undefined_table -- which the catalog reads
	// map to absence, never to another installation's rows
	found, err := empty.Stream[testMessage](sharedName).Get(ctx)
	common.Must(err)
	if found != nil {
		common.Die("an unregistered schema must read no stream, got " + found.Name)
	}
	fmt.Println("   ✅ Get on an unregistered schema is the (nil, nil) absence")

	if _, err := empty.Stream[testMessage](sharedName).Health(ctx); !errors.Is(err, stream.ErrStreamNotFound) {
		common.Die(fmt.Sprintf("every verb but Get should raise absence, got %v", err))
	}
	fmt.Println("   ✅ every other verb raises ErrStreamNotFound rather than reading a neighbour")

	// public is the one schema every search_path ends with, so an installation
	// there is what an unqualified statement falls through to. What keeps the
	// reads above absences is that sqlstreams's SQL names its own schema -- not
	// that public happens to be empty.
	publicClient, publicDs := openClient(ctx, "public", shared)
	defer publicDs.Pool.Close()
	common.Must(publicClient.System().Register(ctx, nil))
	defer func() { common.Must(publicClient.System().Destroy(ctx, &sqlstreams.DestroyOptions{Force: true})) }()
	_, err = publicClient.Stream[testMessage](sharedName).Register(ctx, nil)
	common.Must(err)

	found, err = empty.Stream[testMessage](sharedName).Get(ctx)
	common.Must(err)
	if found != nil {
		common.Die("a full installation in public must not become the empty schema's answer, got " + found.Name)
	}
	fmt.Println("   ✅ with a whole installation standing in public, Get is still the absence")

	if _, err := empty.Stream[testMessage](sharedName).Health(ctx); !errors.Is(err, stream.ErrStreamNotFound) {
		common.Die(fmt.Sprintf("every verb but Get should still raise absence, got %v", err))
	}
	fmt.Println("   ✅ ...and every other verb still raises ErrStreamNotFound")

	fmt.Println("\n=== 4. locks ===")

	// hold the key sqlstreams derives for a register on the left schema -- the
	// register blocking on it is what proves the datastore takes the same one
	const lockedName = "schema.locked"
	lockKey, err := iCommon.NewAdvisoryLockKey("stream", leftSchema, lockedName)
	common.Must(err)

	holder, err := leftDs.Pool.Acquire(ctx)
	common.Must(err)
	defer holder.Release()
	_, err = holder.Exec(ctx, `SELECT pg_advisory_lock($1);`, lockKey.Value())
	common.Must(err)

	if lockKey.ClassId() != iCommon.AdvisoryLockNamespace {
		common.Die(fmt.Sprintf("every key should carry the namespace, got classid %d", lockKey.ClassId()))
	}

	// the same predicate migrate.isLocked reads: finding the lock by the two
	// halves proves ClassId and ObjId split it the way postgres filed it
	var held int
	common.Must(leftDs.Pool.QueryRow(ctx, `
		SELECT count(*) FROM pg_locks
		WHERE locktype = 'advisory'
			AND classid = $1
			AND objid = $2
			AND objsubid = 1
			AND granted;
	`, lockKey.ClassId(), lockKey.ObjId()).Scan(&held))
	if held != 1 {
		common.Die(fmt.Sprintf("pg_locks should hold the key under classid %d objid %d, found %d rows", lockKey.ClassId(), lockKey.ObjId(), held))
	}
	fmt.Printf("   ✅ the held lock reads back under classid %d -- sqlstreams's namespace -- and objid %d\n", lockKey.ClassId(), lockKey.ObjId())

	blocked, cancelBlocked := context.WithTimeout(ctx, 2*time.Second)
	defer cancelBlocked()
	if _, err := left.Stream[sqlstreams.RawPayload](lockedName).Register(blocked, nil); err == nil {
		common.Die("registering under the held key should have waited, it returned")
	}
	fmt.Println("   ✅ the same schema's register waits on the held key")

	free, cancelFree := context.WithTimeout(ctx, 2*time.Second)
	defer cancelFree()
	if _, err := right.Stream[sqlstreams.RawPayload](lockedName).Register(free, nil); err != nil {
		common.Die("the other schema's register must not wait on it: " + err.Error())
	}
	fmt.Println("   ✅ the other schema's register takes a different key and completes")

	_, err = holder.Exec(ctx, `SELECT pg_advisory_unlock($1);`, lockKey.Value())
	common.Must(err)

	fmt.Println("\n✅ SCHEMA E2E TEST PASSED")
	fmt.Println("   one schema is one installation: the same stream name registers in each,")
	fmt.Println("   messages and lifecycles are separate, no read crosses the boundary, and")
	fmt.Println("   neither installation waits on the other's locks.")
	return nil
}

// ***************
// *** HELPERS ***
// ***************

func openClient(ctx context.Context, schema string, cfg *sqlstreams.ClientConfig) (*sqlstreams.Client, *iDatastore.PostgresDatastore) {
	pool, err := common.NewPool(ctx, nil)
	common.Must(err)

	clientConfig := *cfg
	clientConfig.Schema = schema

	client, err := sqlstreams.NewClient(ctx, pool, &clientConfig)
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, &iDatastore.PostgresDatastoreConfig{
		Schema: clientConfig.Schema, Logger: clientConfig.Logger, Retry: clientConfig.Retry,
	})
	common.Must(err)
	return client, ds
}

// boundSchemas lists the schema values a datastore's logger binds onto every
// line it writes.
func boundSchemas(logger logging.Logger) []string {
	pipeline, ok := logger.(*logging.PipelineLogger)
	if !ok {
		common.Die("a datastore's logger should be a pipeline")
	}

	found := []string{}
	args := pipeline.Config.Args
	for i := 0; i+1 < len(args); i += 2 {
		if key, keyOk := args[i].(string); keyOk && key == "schema" {
			found = append(found, fmt.Sprint(args[i+1]))
		}
	}
	return found
}

func tableCount(ctx context.Context, ds *iDatastore.PostgresDatastore, schema string) int {
	var count int
	err := ds.Pool.QueryRow(ctx,
		`SELECT count(*) FROM information_schema.tables WHERE table_schema = $1;`, schema).Scan(&count)
	common.Must(err)
	return count
}

func messageCount(ctx context.Context, ds *iDatastore.PostgresDatastore, schema string, streamId int64) int {
	var count int
	err := ds.Pool.QueryRow(ctx,
		fmt.Sprintf(`SELECT count(*) FROM %s.%s;`, schema, stream.MessageLogTable(streamId))).Scan(&count)
	common.Must(err)
	return count
}

func countNamed(streams []*sqlstreams.Stream, name string) int {
	found := 0
	for _, data := range streams {
		if data.Name == name {
			found++
		}
	}
	return found
}

func dropSchemas(ctx context.Context, ds *iDatastore.PostgresDatastore, schemas ...string) {
	for _, schema := range schemas {
		if _, err := ds.Pool.Exec(ctx, fmt.Sprintf(`DROP SCHEMA IF EXISTS %s CASCADE;`, schema)); err != nil {
			fmt.Printf("   cleanup: %s\n", err.Error())
		}
	}
}
