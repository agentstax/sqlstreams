package main

// compaction-key deadlock e2e test: where reverse-ordered compaction_head lock
// cycles can and cannot happen.
//
// Registers its own stream (destroyed on exit), fully self-contained.
//
// Confirms, in order:
//   - default (batched) Produce cannot deadlock: every batch transaction
//     takes its compaction_head row locks in ascending key order (the
//     batcher's sort), so concurrent batchers hammering the same hot key
//     pool queue behind each other instead of cycling --
//     pg_stat_database.deadlocks stays flat across the run, every produce
//     lands, and each key's head converges to its true max id.
//   - two InTransaction callers producing the same two keys in reverse
//     order genuinely deadlock: Postgres kills exactly one (40P01) after
//     deadlock_timeout, the surfaced error classifies transient
//     (iCommon.IsTransientPgError), and rerunning the victim's closure --
//     the caller-side retry the InTransaction docs require -- lands both
//     callers' messages and both keys' heads still converge.

import (
	"context"
	"errors"
	"fmt"
	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	"github.com/agentstax/sqlstreams/pkg/stream"
	"os"
	"sync"
	"time"
	"uuid"

	iCommon "github.com/agentstax/sqlstreams/pkg/common"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/jackc/pgx/v5/pgconn"
)

type testMessage struct {
	Note string
}

func (testMessage) SchemaVersion() int { return 1 }

const (
	hotKeyCount          = 8
	producerCount        = 3
	goroutineCount       = 120
	producesPerGoroutine = 25
)

var (
	ds         *iDatastore.PostgresDatastore
	client     *sqlstreams.Client
	streamName string
	streamId   int64
	// wpInstance is the shared instance scenario 2 seeds and produces through.
	wpInstance *sqlstreams.ProducerInstance[testMessage]
)

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err = sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err = iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName = fmt.Sprintf("compactiondeadlock.%d", time.Now().UnixNano())
	registered, err := client.Stream[testMessage](streamName).Register(ctx, nil)
	common.Must(err)
	streamId = registered.Id
	defer func() {
		common.Must(client.Stream[testMessage](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	wpInstance, err = client.Stream[testMessage](streamName).Producer().Register(ctx, nil)
	common.Must(err)

	batcherAbsenceScenario(ctx)
	produceInTxDeadlockScenario(ctx)

	fmt.Println("\n✅ COMPACTION DEADLOCK E2E TEST PASSED")
	fmt.Println("   batched produce over a hot key pool raised zero deadlocks (ascending")
	fmt.Println("   key order holds across concurrent batchers); reverse-ordered")
	fmt.Println("   InTransaction callers raised exactly one 40P01, classified transient,")
	fmt.Println("   and a caller-side rerun landed both -- heads converged either way.")
	return nil
}

// batcherAbsenceScenario hammers default Produce from several producer
// instances over one small key pool, every goroutine walking the pool from a
// different starting offset -- maximal reverse-order pressure at enqueue,
// which the batcher's ascending sort must neutralize.
func batcherAbsenceScenario(ctx context.Context) {
	step("default produce: concurrent batchers over a hot key pool never deadlock")
	deadlocksBefore := deadlockCount(ctx)

	instances := make([]*sqlstreams.ProducerInstance[testMessage], producerCount)
	for i := range instances {
		instance, err := client.Stream[testMessage](streamName).Producer().Register(ctx, nil)
		common.Must(err)
		instances[i] = instance
	}

	keys := make([]string, hotKeyCount)
	for i := range keys {
		keys[i] = fmt.Sprintf("hot-%d", i)
	}

	var errOnce sync.Once
	var firstErr error
	record := func(err error) { errOnce.Do(func() { firstErr = err }) }

	started := time.Now()
	var wg sync.WaitGroup
	for i := range goroutineCount {
		wg.Add(1)
		go func(instance *sqlstreams.ProducerInstance[testMessage], offset int) {
			defer wg.Done()
			for produced := range producesPerGoroutine {
				key := keys[(offset+produced)%len(keys)]
				if _, err := instance.Produce(ctx, &testMessage{Note: key}, &sqlstreams.ProduceOptions{MessageKey: key, Compaction: &sqlstreams.CompactionOptions{Enable: true}}); err != nil {
					record(err)
					return
				}
			}
		}(instances[i%producerCount], i)
	}
	wg.Wait()
	common.Must(firstErr)
	elapsed := time.Since(started)

	total := goroutineCount * producesPerGoroutine
	assertInt64("every produce landed as a row", messageCount(ctx), int64(total))
	for _, key := range keys {
		assertHeadIsMaxId(ctx, key)
	}

	// pg_stat flushes per backend within ~1s of going idle -- settle, then read
	time.Sleep(2 * time.Second)
	assertInt64("deadlocks raised during the run", deadlockCount(ctx)-deadlocksBefore, 0)
	fmt.Printf("  ✓ %d produces, %d goroutines, %d hot keys, zero deadlocks (%.0f msgs/s)\n",
		total, goroutineCount, hotKeyCount, float64(total)/elapsed.Seconds())
}

// produceInTxDeadlockScenario is TEST.md's RETRY-40P01 scenario made
// runnable: caller A produces tx-a then tx-b, caller B produces tx-b then
// tx-a, a barrier between the first and second produces guaranteeing both
// hold their first head row lock before either wants the second.
func produceInTxDeadlockScenario(ctx context.Context) {
	step("reverse-ordered ProduceInTx: one 40P01 victim, caller-side rerun lands both")

	// seed both head rows so the second produces contend on existing rows
	for _, key := range []string{"tx-a", "tx-b"} {
		_, err := wpInstance.Produce(ctx, &testMessage{Note: "seed"}, &sqlstreams.ProduceOptions{MessageKey: key, Compaction: &sqlstreams.CompactionOptions{Enable: true}})
		common.Must(err)
	}
	deadlocksBefore := deadlockCount(ctx)

	aHoldsFirst := make(chan struct{})
	bHoldsFirst := make(chan struct{})
	var aOnce, bOnce sync.Once
	results := make(chan callerResult, 2)
	go func() {
		results <- runCallerWithRetry(ctx, "tx-a", "tx-b", &aOnce, aHoldsFirst, bHoldsFirst)
	}()
	go func() {
		results <- runCallerWithRetry(ctx, "tx-b", "tx-a", &bOnce, bHoldsFirst, aHoldsFirst)
	}()

	deadlocksSeen := 0
	var victimWait time.Duration
	for range 2 {
		result := <-results
		common.Must(result.err)
		deadlocksSeen += result.deadlocks
		if result.victimWait > victimWait {
			victimWait = result.victimWait
		}
	}
	assertInt64("40P01s surfaced to the callers", int64(deadlocksSeen), 1)

	waitDeadlockCount(ctx, deadlocksBefore+1)
	for _, key := range []string{"tx-a", "tx-b"} {
		// one seed + one row per caller
		assertInt64(fmt.Sprintf("rows under %q", key), keyMessageCount(ctx, key), 3)
		assertHeadIsMaxId(ctx, key)
	}
	fmt.Printf("  ✓ exactly one victim, killed after %v (deadlock_timeout), rerun landed both\n",
		victimWait.Round(10*time.Millisecond))
}

type callerResult struct {
	deadlocks  int
	victimWait time.Duration
	err        error
}

// runCallerWithRetry is one InTransaction caller plus the retry loop the
// InTransaction docs leave to the caller: a 40P01 must classify transient
// and the whole closure reruns. The barrier only gates the first attempt --
// once both channels closed, a rerun sails through against the already
// committed survivor.
func runCallerWithRetry(ctx context.Context, firstKey string, secondKey string, holdOnce *sync.Once, holdsFirst chan struct{}, peerHoldsFirst chan struct{}) callerResult {
	// fixed per-produce keys make the rerun dedup-safe, the documented pattern
	firstIdempotencyKey := uuid.NewV7().String()
	secondIdempotencyKey := uuid.NewV7().String()

	result := callerResult{}
	for range 5 {
		started := time.Now()
		err := client.InTransaction(ctx, func(ctx context.Context, tx sqlstreams.Tx) error {
			if err := produceKeyInTx(ctx, tx, firstKey, firstIdempotencyKey); err != nil {
				return err
			}

			holdOnce.Do(func() { close(holdsFirst) })
			<-peerHoldsFirst
			return produceKeyInTx(ctx, tx, secondKey, secondIdempotencyKey)
		})
		if err == nil {
			return result
		}

		pgErr, ok := errors.AsType[*pgconn.PgError](err)
		if !ok || pgErr.Code != "40P01" {
			result.err = fmt.Errorf("want only 40P01 surfacing: %w", err)
			return result
		}
		if !iCommon.IsTransientPgError(err) {
			result.err = fmt.Errorf("40P01 must classify transient: %w", err)
			return result
		}
		result.deadlocks++
		result.victimWait = time.Since(started)
	}
	result.err = errors.New("caller never committed within 5 attempts")
	return result
}

func produceKeyInTx(ctx context.Context, tx sqlstreams.Tx, key string, idempotencyKey string) error {
	_, err := wpInstance.ProduceInTx(ctx, tx, &testMessage{Note: key}, &sqlstreams.ProduceOptions{MessageKey: key, Compaction: &sqlstreams.CompactionOptions{Enable: true}, IdempotencyKey: idempotencyKey})
	return err
}

func deadlockCount(ctx context.Context) int64 {
	var count int64
	common.Must(ds.Pool.QueryRow(ctx, `SELECT deadlocks FROM pg_stat_database WHERE datname = current_database();`).Scan(&count))
	return count
}

// waitDeadlockCount polls until the database-wide counter reaches want --
// pg_stat lags each backend's flush, so a plain read races it.
func waitDeadlockCount(ctx context.Context, want int64) {
	deadline := time.Now().Add(10 * time.Second)
	for {
		got := deadlockCount(ctx)
		if got == want {
			return
		}
		if got > want {
			common.Die(fmt.Sprintf("deadlock counter overshot: got %d, want %d", got, want))
		}
		if time.Now().After(deadline) {
			common.Die(fmt.Sprintf("deadlock counter never reached %d, still %d", want, got))
		}
		time.Sleep(200 * time.Millisecond)
	}
}

func messageCount(ctx context.Context) int64 {
	var count int64
	common.Must(ds.Pool.QueryRow(ctx,
		fmt.Sprintf(`SELECT COUNT(*) FROM %s.%s WHERE message_key LIKE 'hot-%%';`, ds.Schema, stream.MessageLogTable(streamId))).Scan(&count))
	return count
}

func keyMessageCount(ctx context.Context, key string) int64 {
	var count int64
	common.Must(ds.Pool.QueryRow(ctx,
		fmt.Sprintf(`SELECT COUNT(*) FROM %s.%s WHERE message_key = $1;`, ds.Schema, stream.MessageLogTable(streamId)), key).Scan(&count))
	return count
}

// assertHeadIsMaxId confirms a key's compaction_head row points at the key's
// highest message id -- all e2e test produces are rank 0, so arrival order (the id
// tiebreak) must decide every winner no matter how commits interleaved.
func assertHeadIsMaxId(ctx context.Context, key string) {
	var headId int64
	var maxId int64
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`
		SELECT
			h.message_id,
			(SELECT MAX(id) FROM %s.%s WHERE message_key = $1)
		FROM %s.%s h
		WHERE h.compaction_key = $1;`, ds.Schema, stream.MessageLogTable(streamId), ds.Schema, stream.CompactionHeadTable(streamId)), key).Scan(&headId, &maxId))
	if headId != maxId {
		common.Die(fmt.Sprintf("head for %q must converge to the max id: got %d, want %d", key, headId, maxId))
	}
}

func assertInt64(name string, got int64, want int64) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", name, got, want))
	}
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
