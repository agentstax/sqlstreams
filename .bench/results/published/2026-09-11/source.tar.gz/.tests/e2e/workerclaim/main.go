// Command workerclaim proves worker-claim coordination across a fleet of
// consumers.
//
// Registers its own stream (destroyed on exit), then runs three Consumers in
// one group and watches live worker_instance rows. The maintenance workers
// on the group's chain (janitor, cursor advancer) are target-1 rows: EXACTLY one
// live instance each no matter how many processes reconcile them -- the
// claim gate arbitrates, not leader election. The message_consumer row is
// the deliberate contrast: its target is unbounded, so every process runs
// its own consume loop.
//
// Confirms: three consumers -> one live janitor/cursor-advancer instance (never
// three) beside three consume loops; killing two, the survivor's manager
// re-claims whatever they held within a reconcile tick; killing the last,
// every claim releases and nothing stays live -- and the workers actually
// did their jobs (committed reached head).
package main

import (
	"context"
	"fmt"
	"github.com/agentstax/sqlstreams/pkg/stream"
	"os"
	"time"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
)

const (
	group       = "workerclaim"
	consumers   = 3
	seedRows    = 200
	instanceTTL = 2 * time.Second
)

// the target-1 rows on the group's chain; the manager rows are unbounded by
// design, and the system's schedule_producer is shared state outside this
// e2e test's stream
var exclusive = []string{"stream_janitor", "cursor_advancer"}

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName := fmt.Sprintf("workerclaim.%d", time.Now().UnixNano())
	tp, err := client.Stream[common.Work](streamName).Register(ctx, &sqlstreams.StreamConfig{})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[common.Work](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)
	for range seedRows {
		_, err := wpInstance.ProduceFunc(ctx, func(ctx context.Context, tx sqlstreams.Tx) (*common.Work, error) {
			return common.NewWork(30, "admin@example.com")
		}, nil)
		common.Must(err)
	}
	head := scalar(ctx, ds, fmt.Sprintf(`SELECT COALESCE(max(id),0) FROM %s.%s`, ds.Schema, stream.MessageLogTable(tp.Id)))
	fmt.Printf("stream=%q id=%d seeded head=%d, instance ttl=%s, %d consumers\n", streamName, tp.Id, head, instanceTTL, consumers)

	running := make([]*runningConsumer, 0, consumers)
	for i := range consumers {
		running = append(running, start(ctx, client, tp.Name, i))
	}
	groupId := scalar(ctx, ds, fmt.Sprintf(`SELECT id FROM %s.consumer_group_config WHERE stream_id=$1 AND name=$2`, ds.Schema), tp.Id, group)

	// ===== phase 1: N consumers, one live instance per target-1 row =====
	step("PHASE 1: 3 consumers for 8s -- janitor/cursor-advancer hold exactly 1 live instance, never 3")
	maxLive, live := sampleLive(ctx, ds, tp.Id, groupId, 8*time.Second)
	for _, name := range exclusive {
		fmt.Printf("  %-18s live=%d max seen=%d\n", name, live[name], maxLive[name])
		assertInt(name+" never exceeded its target", int64(maxLive[name]), 1)
		assertInt(name+" is claimed", int64(live[name]), 1)
	}
	fmt.Printf("  %-18s live=%d\n", "message_consumer", live["message_consumer"])
	assertInt("message_consumer runs unbounded -- one loop per process", int64(live["message_consumer"]), consumers)

	// ===== phase 2: kill two consumers, the survivor re-claims =====
	step("PHASE 2: kill 2 of 3 -- the survivor's manager re-claims whatever they held")
	for _, rc := range running[:2] {
		rc.stop()
	}
	maxLive, live = sampleLive(ctx, ds, tp.Id, groupId, 6*time.Second)
	for _, name := range exclusive {
		fmt.Printf("  %-18s live=%d max seen=%d\n", name, live[name], maxLive[name])
		assertInt(name+" still never exceeded its target", int64(maxLive[name]), 1)
		assertInt(name+" re-claimed after failover", int64(live[name]), 1)
	}
	assertInt("one consume loop left", int64(live["message_consumer"]), 1)

	// ===== phase 3: kill the last -- every claim releases =====
	step("PHASE 3: kill the survivor -- claims release, nothing stays live")
	running[2].stop()
	time.Sleep(instanceTTL) // a released row is gone at once; the TTL wait covers a claim mid-renewal
	_, live = sampleLive(ctx, ds, tp.Id, groupId, 2*time.Second)
	for _, name := range append(exclusive, "message_consumer") {
		fmt.Printf("  %-18s live=%d\n", name, live[name])
		assertInt(name+" has no live instance", int64(live[name]), 0)
	}

	// ===== the workers actually did their jobs =====
	step("END STATE: the coordinated workers did real work")
	assertInt("committed reached head", scalar(ctx, ds, fmt.Sprintf(`SELECT c.committed FROM %s.%s c JOIN %s.consumer_group_config g ON g.id = c.consumer_group_id WHERE g.name=$1`, ds.Schema, stream.ConsumerGroupCursorTable(tp.Id), ds.Schema), group), head)

	fmt.Println("\n✅ WORKER CLAIM E2E TEST PASSED")
	fmt.Println("   3 consumers -> one live instance per target-1 worker row, failover to the")
	fmt.Println("   survivor within a reconcile tick, full release when the last one exits.")
	return nil
}

// runningConsumer is one Consumer's lifecycle handle: cancel stops it, done
// yields Consume's return.
type runningConsumer struct {
	cancel context.CancelFunc
	done   chan error
}

func (rc *runningConsumer) stop() {
	rc.cancel()
	common.Must(<-rc.done)
}

func start(ctx context.Context, client *sqlstreams.Client, streamName string, i int) *runningConsumer {
	lifecycleCtx, cancel := context.WithCancel(ctx)
	cInstance, err := client.Stream[common.Work](streamName).Consumer(group).Register(lifecycleCtx, nil)
	common.Must(err)

	options := &sqlstreams.ConsumeOptions{
		BatchLimit:         50,
		QueueSize:          64,
		MessageConcurrency: 4,
		ClaimPollRate:      100 * time.Millisecond,
		InstanceTTL:        instanceTTL,
	}

	done := make(chan error, 1)
	go func() {
		err := cInstance.Consume(lifecycleCtx, func(ctx context.Context, work *common.Work) error { return nil }, options)
		if err != nil && lifecycleCtx.Err() == nil {
			fmt.Printf("  consumer %d died early: %v\n", i, err)
		}
		done <- err
	}()
	fmt.Printf("  consumer %d started\n", i)
	return &runningConsumer{cancel: cancel, done: done}
}

// sampleLive polls the chain's worker rows for dur and tracks live instance
// counts per row: the last count seen and the highest ever seen -- the max
// is what proves the claim gate held while processes fought over it.
func sampleLive(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64, groupId int64, dur time.Duration) (map[string]int, map[string]int) {
	maxLive := map[string]int{}
	live := map[string]int{}
	deadline := time.Now().Add(dur)
	for time.Now().Before(deadline) {
		rows, err := ds.Pool.Query(ctx, fmt.Sprintf(`
			SELECT w.name, COUNT(i.id) FILTER (WHERE i.expires_at > now())
			FROM %s.worker_config w
			LEFT JOIN %s.worker_instance i ON i.worker_id = w.id
			WHERE w.stream_id = $1
				OR w.consumer_group_id = $2
			GROUP BY w.name`, ds.Schema, ds.Schema), streamId, groupId)
		common.Must(err)
		for rows.Next() {
			var name string
			var n int
			common.Must(rows.Scan(&name, &n))
			live[name] = n
			if n > maxLive[name] {
				maxLive[name] = n
			}
		}
		common.Must(rows.Err())
		rows.Close()
		time.Sleep(50 * time.Millisecond)
	}
	return maxLive, live
}

// ---- helpers ----

func scalar(ctx context.Context, ds *iDatastore.PostgresDatastore, q string, args ...any) int64 {
	var v int64
	common.Must(ds.Pool.QueryRow(ctx, q, args...).Scan(&v))
	return v
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }

func assertInt(label string, got, want int64) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", label, got, want))
	}
	fmt.Printf("  ✓ %s (%d)\n", label, got)
}
