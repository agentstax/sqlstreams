package main

// binding lifecycle e2e test: a group's set is declared at Register and replaced
// only when no live instance still declares it.
//
// Registers its own stream, destroyed on exit. Drives the consumer API end to
// end -- real Register attempts, a real consuming incumbent whose heartbeats
// block the swap, and a real Consume blocked in its declaration wait.
//
// Confirms: a re-Register of the same set joins without writing; a divergent
// set against a live incumbent waits -- visibly, appending a waiting row per
// retry, never touching the effective set, never starting the manager; the
// declaration listing shows the effective row and the open waiter; stopping
// the incumbent (the rolling deploy's kill) lets the waiter install, swap the
// binding rows, and consume messages routed to its set; the ended wait
// disappears from the listing; the consumer group janitor's sweep deletes
// superseded waiting rows past the TTL while keeping each declarer's newest
// waiting row and every installed row.

import (
	"context"
	"fmt"
	"os"
	"time"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	"github.com/agentstax/sqlstreams/pkg/consume"
	consumejanitorcontroller "github.com/agentstax/sqlstreams/pkg/consume/janitor/controller"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/agentstax/sqlstreams/pkg/stream"
)

type testMessage struct {
	Note string
}

func (testMessage) SchemaVersion() int { return 1 }

const groupName = "binding.group"

var (
	ds         *iDatastore.PostgresDatastore
	client     *sqlstreams.Client
	streamName string
	streamId   int64
	groupId    int64
)

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err = sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err = iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName = fmt.Sprintf("binding.%d", time.Now().UnixNano())
	registered, err := client.Stream[testMessage](streamName).Register(ctx, nil)
	common.Must(err)
	streamId = registered.Id
	defer func() {
		common.Must(client.Stream[testMessage](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	// ===== install + join =====
	step("Register declares the set; a same-set Register joins without writing")
	incumbent, err := registerConsumer(ctx, []string{"orders.*"})
	common.Must(err)
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT id FROM %s.consumer_group_config WHERE stream_id = $1 AND name = $2;`, ds.Schema),
		registered.Id, groupName).Scan(&groupId))
	assertInt("one installed row", installedRows(ctx), 1)
	assertString("binding rows", bindingDisplays(ctx), "orders.*")

	_, err = registerConsumer(ctx, []string{"orders.*"})
	common.Must(err)
	assertInt("still one installed row after the same set re-registers", installedRows(ctx), 1)
	assertString("Binding().Get reads the installed set", patterns(testBinding(ctx)), "orders.*")
	absent, err := client.Stream[testMessage](streamName).Consumer("binding.never-declared").Binding().Get(ctx)
	common.Must(err)
	if absent != nil {
		common.Die("Binding().Get on an unregistered group must return nil")
	}
	fmt.Println("  ✓ installed once, joined on re-register; Get reads the set, nil for an absent group")

	// ===== divergent set waits on the live incumbent =====
	step("a divergent set waits while the incumbent's heartbeats are fresh")
	incumbentCtx, stopIncumbent := context.WithCancel(ctx)
	incumbentDone := make(chan error, 1)
	go func() {
		incumbentDone <- incumbent.Consume(incumbentCtx, func(ctx context.Context, message *testMessage) error {
			return nil
		}, consumeOptions)
	}()
	waitLiveInstance(ctx)

	divergent, err := registerConsumer(ctx, []string{"payments.*"})
	common.Must(err)
	received := make(chan string, 1)
	divergentCtx, stopDivergent := context.WithCancel(ctx)
	divergentDone := make(chan error, 1)
	go func() {
		divergentDone <- divergent.Consume(divergentCtx, func(ctx context.Context, message *testMessage) error {
			select {
			case received <- message.Note:
			default:
			}
			return nil
		}, consumeOptions)
	}()

	// several retry intervals pass; the wait appends rows and changes nothing
	time.Sleep(1500 * time.Millisecond)
	select {
	case err := <-divergentDone:
		common.Die(fmt.Sprintf("the divergent Consume must stay blocked, returned %v", err))
	default:
	}
	assertString("binding rows still the incumbent's", bindingDisplays(ctx), "orders.*")
	if got := waitingRows(ctx); got < 2 {
		common.Die(fmt.Sprintf("want the wait re-appended as rows, got %d", got))
	}
	installed, waiter := testDeclarations(ctx)
	if installed == nil || patterns(installed) != "orders.*" {
		common.Die("listing must show the incumbent's set as installed")
	}
	if waiter == nil || patterns(waiter) != "payments.*" {
		common.Die("listing must show the divergent set as waiting")
	}
	assertString("Binding().Get still reads the incumbent's set during the wait", patterns(testBinding(ctx)), "orders.*")
	fmt.Println("  ✓ waited: rows appended, effective set untouched, listing shows the open wait")

	// ===== the deploy kills the incumbent; the waiter converges =====
	step("stopping the incumbent lets the waiter install, swap, and consume")
	stopIncumbent()
	common.Must(<-incumbentDone)

	deadline := time.Now().Add(30 * time.Second)
	for bindingDisplays(ctx) != "payments.*" {
		if time.Now().After(deadline) {
			common.Die("the waiter never installed after the incumbent stopped")
		}
		time.Sleep(200 * time.Millisecond)
	}
	installed, waiter = testDeclarations(ctx)
	if installed == nil || patterns(installed) != "payments.*" {
		common.Die("listing must show the swapped set as installed")
	}
	if waiter != nil {
		common.Die("the ended wait must leave the listing")
	}
	assertString("Binding().Get reads the swapped set", patterns(testBinding(ctx)), "payments.*")
	fmt.Println("  ✓ swapped once the incumbent's heartbeats lapsed; wait left the listing")

	wpInstance, err := client.Stream[testMessage](streamName).Producer().Register(ctx, nil)
	common.Must(err)
	_, err = wpInstance.Produce(ctx, &testMessage{Note: "charged"}, &sqlstreams.ProduceOptions{RoutingKey: "payments.charge"})
	common.Must(err)
	select {
	case note := <-received:
		assertString("consumed under the new set", note, "charged")
	case <-time.After(30 * time.Second):
		common.Die("the installed consumer never consumed a message routed to its set")
	}
	stopDivergent()
	common.Must(<-divergentDone)
	fmt.Println("  ✓ consumed a message routed to the new set, stopped clean")

	// ===== retention: the janitor sweeps superseded waiting rows =====
	step("the consumer group janitor sweeps superseded waiting rows, keeping each declarer's newest")
	syntheticNewestId := insertSyntheticWaits(ctx)
	beforeSweep := waitingRows(ctx)
	_, err = ds.Pool.Exec(ctx,
		fmt.Sprintf(`UPDATE %s.%s SET attempted_at = attempted_at - interval '8 days' WHERE consumer_group_id = $1;`, ds.Schema, stream.BindingConfigLogTable(streamId)),
		groupId)
	common.Must(err)

	sweepController, err := consumejanitorcontroller.NewJanitorController(ds, ds.Logger)
	common.Must(err)
	swept, err := sweepController.SweepExpiredWaitingDeclarations(ctx, 7*24*time.Hour, 1000)
	common.Must(err)
	assertInt("swept superseded waiting rows", int(swept), beforeSweep-2)
	assertInt("one waiting row per declarer survives past the TTL", waitingRows(ctx), 2)
	assertInt("installed rows untouched", installedRows(ctx), 2)

	var survivingSyntheticId int64
	common.Must(ds.Pool.QueryRow(ctx,
		fmt.Sprintf(`SELECT id FROM %s.%s WHERE consumer_group_id = $1 AND declared_by = 'binding.dead-declarer';`, ds.Schema, stream.BindingConfigLogTable(streamId)),
		groupId).Scan(&survivingSyntheticId))
	if survivingSyntheticId != syntheticNewestId {
		common.Die(fmt.Sprintf("the dead declarer's newest waiting row must survive: got id %d, want %d", survivingSyntheticId, syntheticNewestId))
	}

	swept, err = sweepController.SweepExpiredWaitingDeclarations(ctx, 7*24*time.Hour, 1000)
	common.Must(err)
	assertInt("a second sweep deletes nothing", int(swept), 0)
	fmt.Println("  ✓ superseded rows swept; each declarer's newest waiting row and all installed rows kept")

	fmt.Println("\n✅ BINDING E2E TEST PASSED")
	return nil
}

// registerConsumer declares the e2e test group's set.
func registerConsumer(ctx context.Context, bindings []string) (*sqlstreams.ConsumerInstance[testMessage], error) {
	return client.Stream[testMessage](streamName).Consumer(groupName).Register(ctx, &sqlstreams.ConsumerConfig{
		Bindings: bindings,
	})

}

// consumeOptions holds the e2e test's tight heartbeat and retry knobs, passed to
// every Consume session.
var consumeOptions = &sqlstreams.ConsumeOptions{
	ClaimPollRate:        500 * time.Millisecond,
	InstanceTTL:          2 * time.Second,
	BindingRetryInterval: 300 * time.Millisecond,
}

// waitLiveInstance blocks until the consuming incumbent's heartbeat rows
// exist -- before that a divergent Register would install, not wait.
func waitLiveInstance(ctx context.Context) {
	deadline := time.Now().Add(30 * time.Second)
	for {
		var live bool
		common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`
			SELECT EXISTS (
				SELECT 1
				FROM %s.worker_instance
				JOIN %s.worker_config ON worker_config.id = worker_instance.worker_id
				WHERE worker_config.consumer_group_id = $1 AND worker_instance.expires_at > now()
			);`, ds.Schema, ds.Schema), groupId).Scan(&live))
		if live {
			return
		}
		if time.Now().After(deadline) {
			common.Die("the incumbent never wrote a live worker_instance row")
		}
		time.Sleep(200 * time.Millisecond)
	}
}

// insertSyntheticWaits appends three waiting rows for a declarer whose
// process is gone -- the dead waiter the sweep must keep visible. Returns
// the newest row's id.
func insertSyntheticWaits(ctx context.Context) int64 {
	var newestId int64
	for range 3 {
		common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`
			INSERT INTO %s.%s (consumer_group_id, status, patterns, declared_by, declared_at)
			VALUES ($1, 'waiting', '{"refunds.*"}', 'binding.dead-declarer', now())
			RETURNING id;`, ds.Schema, stream.BindingConfigLogTable(streamId)), groupId).Scan(&newestId))
	}
	return newestId
}

func installedRows(ctx context.Context) int {
	var count int
	common.Must(ds.Pool.QueryRow(ctx,
		fmt.Sprintf(`SELECT COUNT(*) FROM %s.%s WHERE consumer_group_id = $1 AND status = 'installed';`, ds.Schema, stream.BindingConfigLogTable(streamId)),
		groupId).Scan(&count))
	return count
}

func waitingRows(ctx context.Context) int {
	var count int
	common.Must(ds.Pool.QueryRow(ctx,
		fmt.Sprintf(`SELECT COUNT(*) FROM %s.%s WHERE consumer_group_id = $1 AND status = 'waiting';`, ds.Schema, stream.BindingConfigLogTable(streamId)),
		groupId).Scan(&count))
	return count
}

func bindingDisplays(ctx context.Context) string {
	var displays string
	common.Must(ds.Pool.QueryRow(ctx,
		fmt.Sprintf(`SELECT COALESCE(string_agg(pattern, ',' ORDER BY pattern), '') FROM %s.%s WHERE consumer_group_id = $1;`, ds.Schema, stream.BindingConfigTable(streamId)),
		groupId).Scan(&displays))
	return displays
}

// testDeclarations reads the listing surface and returns the e2e test group's
// installed row and open waiting row (nil when absent).
func testDeclarations(ctx context.Context) (*consume.Binding, *consume.Binding) {
	declarations, err := client.System().Bindings(ctx)
	common.Must(err)
	var installed *consume.Binding
	var waiter *consume.Binding
	for _, declaration := range declarations {
		if declaration.StreamName != streamName || declaration.ConsumerGroupName != groupName {
			continue
		}
		switch declaration.Status {
		case consume.BindingInstalled:
			installed = declaration
		case consume.BindingWaiting:
			waiter = declaration
		}
	}
	return installed, waiter
}

// testBinding reads the e2e test group's effective set through the group handle.
func testBinding(ctx context.Context) *consume.Binding {
	binding, err := client.Stream[testMessage](streamName).Consumer(groupName).Binding().Get(ctx)
	common.Must(err)
	if binding == nil {
		common.Die("Binding().Get must find the e2e test group's installed set")
	}
	return binding
}

func patterns(declaration *consume.Binding) string {
	joined := ""
	for i, pattern := range declaration.Patterns {
		if i > 0 {
			joined += ","
		}
		joined += pattern
	}
	return joined
}

func assertInt(name string, got int, want int) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", name, got, want))
	}
}

func assertString(name string, got string, want string) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %q, want %q", name, got, want))
	}
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
