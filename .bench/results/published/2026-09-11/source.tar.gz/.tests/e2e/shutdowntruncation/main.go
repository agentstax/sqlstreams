package main

// Graceful-shutdown lease truncation e2e test.
//
// A shutdown signal mid-range must not force the WHOLE range to sit out a
// full lease-expiry reclaim: everything already resolved (successes + a
// unresolved exception) has to survive via closeOpenRanges' PartialCommit path,
// and only the untouched suffix should remain leased for a future reclaim.
//
// Claims one life straight off MessageConsumerProvisioner (no manager) with pool
// N=1 so message dispatch is strictly serialized: consumerFunc cancels the
// shared context after message 2 finishes, simulating a shutdown signal
// arriving mid-range. Message 3 is already sitting in the buffer (prefetch
// claims the whole range of 3 up front) but N=1 means dispatch can't hand it
// out until message 2's permit releases -- by then ctx is already cancelled,
// so dispatch exits without ever calling WaitForNext for it.
//
// Confirms:
//   - messages before the interruption point resolve normally (one success, one
//     unresolved exception) and are never re-attempted
//   - the message after the interruption point is never even attempted
//   - the lease survives, narrowed to (lastProcessed, high] -- not deleted, not
//     left spanning the whole original range
//   - AdvanceCommitted stays correctly pinned behind the unresolved exception even
//     though the lease is already narrowed past it (the two blockers combine via
//     LEAST, neither overrides the other)
//   - once the exception resolves, committed advances to the narrowed low --
//     it does NOT need the untouched suffix's lease to expire first
//   - once that narrowed lease naturally expires, ONLY the untouched suffix is
//     reclaimed -- the resolved prefix is never redelivered

import (
	"context"
	"errors"
	"fmt"
	"os"
	"sync/atomic"
	"time"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	iCommon "github.com/agentstax/sqlstreams/pkg/common"
	"github.com/agentstax/sqlstreams/pkg/consume"
	consumecontroller "github.com/agentstax/sqlstreams/pkg/consume/controller"
	cursoradvancerdatastore "github.com/agentstax/sqlstreams/pkg/consume/cursoradvancer/controller/datastore"
	exceptionconsumercontroller "github.com/agentstax/sqlstreams/pkg/consume/exceptionconsumer/controller"
	"github.com/agentstax/sqlstreams/pkg/consume/messageconsumer"
	messageconsumercontroller "github.com/agentstax/sqlstreams/pkg/consume/messageconsumer/controller"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	metricsproducer "github.com/agentstax/sqlstreams/pkg/metric/producer"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/agentstax/sqlstreams/pkg/stream"
	workercontroller "github.com/agentstax/sqlstreams/pkg/worker/controller"
)

const group = "phase9.shutdowntruncation"

// Timeout + QueueMargin + RecordMargin below sums to this -- kept equal to the
// leaseDuration used for the manual reclaim call later, so both claims behave
// the same way.
const lease = 2 * time.Second

// set by main from RegisterGroup -- helpers are id-keyed
var groupId int64

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName := fmt.Sprintf("phase9.shutdowntruncation.%d", time.Now().UnixNano())
	tp, err := client.Stream[sqlstreams.RawPayload](streamName).Register(ctx, &sqlstreams.StreamConfig{})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[sqlstreams.RawPayload](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	cd, err := consumecontroller.NewConsumeController(ds, ds.Logger)
	common.Must(err)
	messageConsumers, err := messageconsumercontroller.NewMessageConsumerGroupController(ds, ds.Logger)
	common.Must(err)
	exceptionConsumers, err := exceptionconsumercontroller.NewExceptionConsumerGroupController(ds, ds.Logger)
	common.Must(err)
	cursorAdvancerDatastore, err := cursoradvancerdatastore.NewCursorAdvancerDatastore(ds, ds.Logger)
	common.Must(err)
	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)

	groupId = mustGroupID(cd.RegisterGroup(ctx, tp.Id, group, consume.Beginning()))
	seed(ctx, wpInstance, 3)

	cfg := &messageconsumer.MessageConsumerConfig{
		BatchLimit:         3,
		QueueSize:          10,
		MessageConcurrency: 1,
		Message:            &iCommon.MessageOptions{Timeout: 1 * time.Second},
		QueueMargin:        500 * time.Millisecond,
		RecordMargin:       500 * time.Millisecond, // also PartialCommit's/ForceReclaimRange's own detached-ctx budget
	}
	owner, err := iCommon.NewConsumerGroupOwner(tp.SystemId, tp.Id, groupId, group)
	common.Must(err)
	abandonedEvents, err := metricsproducer.NewMetricsProducer(ds, nil, ds.Logger)
	common.Must(err)
	go func() {
		common.Must(abandonedEvents.Run(ctx, group, tp.Name, 1, "shutdowntruncation-session"))
	}()

	step("WORKER claims all 3, shutdown fires after message 2 -- message 3 never attempted")
	runCtx, cancel := context.WithCancel(ctx)
	var calls atomic.Int64
	consumerFunc := func(ctx context.Context, work *common.Work) error {
		switch n := calls.Add(1); n {
		case 1:
			return nil // success
		case 2:
			cancel() // shutdown signal arrives -- this message still finishes though
			return errors.New("simulated failure")
		default:
			common.Die(fmt.Sprintf("consumerFunc called a %dth time -- message 3 must never be attempted", n))
			return nil
		}
	}
	// claimed straight off the provisioner -- no manager, so nothing respawns the
	// execution and the truncation the e2e test asserts on is the only one
	provisioner, err := messageconsumer.NewMessageConsumerProvisioner(ds, consumerFunc, 1, abandonedEvents, cfg, ds.Logger)
	common.Must(err)
	common.Must(provisioner.Declare(ctx, owner))

	workers, err := workercontroller.NewWorkerController(ds, ds.Logger)
	common.Must(err)
	row, err := workers.GetWorker(ctx, provisioner.Definition().Name, owner)
	common.Must(err)
	execution, err := provisioner.Provision(runCtx, row)
	common.Must(err)

	// Run blocks until runCtx cancels (cancel() fires synchronously inside
	// consumerFunc above) -- N=1 pool means dispatch can't reach message 3
	// before that cancellation is already visible to it.
	if err := execution.Run(runCtx); err != nil && !errors.Is(err, context.Canceled) {
		common.Die(fmt.Sprintf("Run returned an unexpected error: %v", err))
	}
	assertInt64("exactly 2 messages attempted", calls.Load(), 2)

	lb := onlyLease(ctx, ds, tp.Id)
	fmt.Printf("  lease narrowed: (%d,%d] (was (0,%d])\n", lb.low, lb.high, lb.high)
	assertInt64("lease survives (not deleted)", leases(ctx, ds, tp.Id), 1)
	assertInt64("lease high unchanged", lb.high, 3)
	assertInt64("lease low narrowed to message 2", lb.low, 2)
	assertInt64("exactly 1 unresolved exception (message 2)", deliveries(ctx, ds, tp.Id), 1)
	assertStatus(ctx, ds, tp.Id, 2, "ready")

	step("committed stays pinned behind the unresolved exception, even though the lease is already narrowed past it")
	committed := advance(ctx, cursorAdvancerDatastore, tp.Id)
	assertInt64("committed blocked at message 1 (exception at 2 still unresolved)", committed, 1)

	step("sleep 5.5s — let the unresolved exception's initial backoff pass")
	time.Sleep(5500 * time.Millisecond)

	step("resolve the exception -- committed jumps to the narrowed low, no need to wait on the untouched suffix's lease")
	claimedExceptions, err := exceptionConsumers.Claim(ctx, tp.Id, groupId, 1, 10, 3, lease, tp.DeliveryLogMode)
	common.Must(err)
	if len(claimedExceptions) != 1 {
		common.Die(fmt.Sprintf("expected 1 claimed exception, got %d", len(claimedExceptions)))
	}
	common.Must(exceptionConsumers.RecordSuccess(ctx, &claimedExceptions[0], tp.DeliveryLogMode, nil))
	committed = advance(ctx, cursorAdvancerDatastore, tp.Id)
	assertInt64("committed advances to the narrowed low", committed, 2)
	assertInt64("deliveries drained (exception pop-deleted)", deliveries(ctx, ds, tp.Id), 0)

	// the narrowed lease's 2s duration already elapsed during the 5.5s backoff
	// sleep above -- no separate wait needed before reclaiming it.
	step("reclaim: only the untouched suffix comes back, not the resolved prefix")
	claim2, err := messageConsumers.ClaimMessagesWithCursor(ctx, tp.Id, groupId, 1, 3, 3, lease, stream.DeliveryLogModeFailures)
	common.Must(err)
	if claim2 == nil {
		common.Die("expected a reclaim, got nil")
	}
	assertInt64("reclaimed range starts at the narrowed low", claim2.Lease.Low, 2)
	assertInt64("reclaimed range ends at the original high", claim2.Lease.High, 3)
	assertInt64("reclaimed exactly the untouched suffix (1 message)", int64(len(claim2.Messages)), 1)
	assertInt64("reclaimed message is the one never attempted", claim2.Messages[0].Id, 3)

	common.Must(messageConsumers.Commit(ctx, tp.Id, groupId, claim2.Lease.Token, nil, 5*time.Second, stream.DeliveryLogModeFailures))
	committed = advance(ctx, cursorAdvancerDatastore, tp.Id)
	assertInt64("committed reaches head", committed, 3)
	assertInt64("no leases left open", leases(ctx, ds, tp.Id), 0)

	fmt.Println("\n✅ SHUTDOWN LEASE TRUNCATION E2E TEST PASSED")
	fmt.Println("   an interruption mid-range records what resolved and narrows the lease to the")
	fmt.Println("   untouched suffix -- the resolved prefix is never redelivered, committed's")
	fmt.Println("   exception-blocker and lease-narrowing terms combine correctly via LEAST, and")
	fmt.Println("   the untouched suffix reclaims on its own once its (now-shorter) lease expires.")
	return nil
}

// ---- helpers ----

func seed(ctx context.Context, wpInstance *sqlstreams.ProducerInstance[common.Work], n int) {
	for range n {
		_, err := wpInstance.ProduceFunc(ctx, func(ctx context.Context, tx sqlstreams.Tx) (*common.Work, error) {
			return common.NewWork(30, "admin@example.com")
		}, nil)
		common.Must(err)
	}
}

func advance(ctx context.Context, cursorAdvancerDatastore *cursoradvancerdatastore.CursorAdvancerDatastore, streamId int64) int64 {
	c, err := cursorAdvancerDatastore.AdvanceCommitted(ctx, streamId, groupId)
	common.Must(err)
	return c
}

type leaseBounds struct{ low, high int64 }

func onlyLease(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) leaseBounds {
	var lb leaseBounds
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT low, high FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ClaimLeaseTable(streamId)), groupId).Scan(&lb.low, &lb.high))
	return lb
}

func leases(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT count(*) FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ClaimLeaseTable(streamId)), groupId)
}
func deliveries(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT count(*) FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ExceptionQueueTable(streamId)), groupId)
}

func scalar(ctx context.Context, ds *iDatastore.PostgresDatastore, q string, args ...any) int64 {
	var v int64
	common.Must(ds.Pool.QueryRow(ctx, q, args...).Scan(&v))
	return v
}

func assertStatus(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId, messageId int64, want string) {
	var got string
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT status FROM %s.%s WHERE consumer_group_id=$1 AND message_id=$2`, ds.Schema, stream.ExceptionQueueTable(streamId)), groupId, messageId).Scan(&got))
	if got != want {
		common.Die(fmt.Sprintf("message %d status: got %q, want %q", messageId, got, want))
	}
	fmt.Printf("  ✓ message %d status = %q\n", messageId, got)
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
func assertInt64(label string, got, want int64) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", label, got, want))
	}
	fmt.Printf("  ✓ %s (%d)\n", label, got)
}

func mustGroupID(g *consume.Consumer, err error) int64 { common.Must(err); return g.Id }
