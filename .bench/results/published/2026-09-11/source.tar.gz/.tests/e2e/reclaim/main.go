package main

// Phase 6.5b e2e test: crash mid-range, recover.
//
// Registers its own stream (destroyed on exit) and seeds it with 20 messages,
// so the e2e test is fully self-contained -- no dependency on a pre-seeded shared
// message_log the way the pre-8b version needed (`just produce 20` first).
//
// Drives the real datastore methods directly so a "crash" is deterministic: a
// worker claims a range (which opens a lease) and then simply never Commits it --
// exactly what a process that dies mid-range leaves behind. A short lease lets the
// e2e test show the expiry + reclaim without real-time waiting.
//
// Confirms: no exception rows are written, committed stays pinned at the crashed
// range's lo, Reclaim re-reads the EXACT range with a ROTATED token (so the dead
// worker's later commit no-ops), and committed jumps to head once the reclaim
// completes.

import (
	"context"
	"errors"
	"fmt"
	"os"
	"time"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	iCommon "github.com/agentstax/sqlstreams/pkg/common"
	"github.com/agentstax/sqlstreams/pkg/consume"
	consumecontroller "github.com/agentstax/sqlstreams/pkg/consume/controller"
	cursoradvancerdatastore "github.com/agentstax/sqlstreams/pkg/consume/cursoradvancer/controller/datastore"
	messageconsumercontroller "github.com/agentstax/sqlstreams/pkg/consume/messageconsumer/controller"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/agentstax/sqlstreams/pkg/stream"
)

const (
	group    = "phase65b.e2e"
	seedRows = 20
)

// set by main from RegisterGroup -- helpers are id-keyed
var groupId int64

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName := fmt.Sprintf("phase65b.reclaim.%d", time.Now().UnixNano())
	tp, err := client.Stream[sqlstreams.RawPayload](streamName).Register(ctx, &sqlstreams.StreamConfig{})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[sqlstreams.RawPayload](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	cd, err := consumecontroller.NewConsumeController(ds, ds.Logger)
	common.Must(err)
	messageConsumers, err := messageconsumercontroller.NewMessageConsumerGroupController(ds, ds.Logger)
	common.Must(err)
	cursorAdvancerDatastore, err := cursoradvancerdatastore.NewCursorAdvancerDatastore(ds, ds.Logger)
	common.Must(err)
	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)

	groupId = mustGroupID(cd.RegisterGroup(ctx, tp.Id, group, consume.Beginning()))
	for range seedRows {
		_, err := wpInstance.ProduceFunc(ctx, func(ctx context.Context, tx sqlstreams.Tx) (*common.Work, error) {
			return common.NewWork(30, "admin@example.com")
		}, nil)
		common.Must(err)
	}
	head := scalar(ctx, ds, fmt.Sprintf(`SELECT COALESCE(max(id),0) FROM %s.%s`, ds.Schema, stream.MessageLogTable(tp.Id)))
	fmt.Printf("stream=%q id=%d message_log head = %d, group = %q\n", streamName, tp.Id, head, group)

	const lease = 2 * time.Second
	const batch = 10
	const maxRangeReclaims = 3 // this e2e test reclaims exactly once -- never enough to quarantine

	// ===== WORKER 1: claim a range, tick the roller, then CRASH (never commit) =====
	step("WORKER 1 claims a range, then crashes mid-range (never Commit)")
	claim1, err := messageConsumers.ClaimMessagesWithCursor(ctx, tp.Id, groupId, 1, batch, maxRangeReclaims, lease, stream.DeliveryLogModeFailures)
	common.Must(err)
	if claim1 == nil {
		common.Die("expected a fresh claim, got nil (no work?)")
	}
	fmt.Printf("  claimed (%d,%d]  ids=%v  lease=%s\n",
		claim1.Lease.Low, claim1.Lease.High, ids(claim1.Messages), shortTok(claim1.Lease.Token))
	committed := advance(ctx, cursorAdvancerDatastore, tp.Id) // the lazy roller ticks while the range is in-flight
	fmt.Printf("  roller tick -> committed = %d\n", committed)
	// *** CRASH: control never reaches Commit(claim1) ***
	oldTok := shortTok(claim1.Lease.Token)

	snapshot(ctx, ds, tp.Id, "AFTER CRASH")
	assertInt64("no exception rows written", deliveries(ctx, ds, tp.Id), 0)
	assertInt64("committed pinned at range lo", committedCol(ctx, ds, tp.Id), claim1.Lease.Low)
	assertInt64("claimed sits at range hi", claimedCol(ctx, ds, tp.Id), claim1.Lease.High)
	assertInt64("exactly one open lease", leases(ctx, ds, tp.Id), 1)

	// ===== lease expiry =====
	step(fmt.Sprintf("sleep %s — let the crashed lease expire", lease+500*time.Millisecond))
	time.Sleep(lease + 500*time.Millisecond)

	// ===== WORKER 2: Reclaim-before-Claim grabs the EXACT expired range =====
	step("WORKER 2 polls: Reclaim-before-Claim picks up the expired lease")
	claim2, err := messageConsumers.ClaimMessagesWithCursor(ctx, tp.Id, groupId, 1, batch, maxRangeReclaims, lease, stream.DeliveryLogModeFailures)
	common.Must(err)
	if claim2 == nil {
		common.Die("expected a reclaim, got nil")
	}
	fmt.Printf("  reclaimed (%d,%d]  ids=%v  NEW lease=%s (was %s)\n",
		claim2.Lease.Low, claim2.Lease.High, ids(claim2.Messages), shortTok(claim2.Lease.Token), oldTok)
	assertInt64("reclaim re-reads exact range lo", claim2.Lease.Low, claim1.Lease.Low)
	assertInt64("reclaim re-reads exact range hi", claim2.Lease.High, claim1.Lease.High)
	assertInt64("reclaim re-reads same message count", int64(len(claim2.Messages)), int64(len(claim1.Messages)))
	if shortTok(claim2.Lease.Token) == oldTok {
		common.Die("token was NOT rotated — R5 violated")
	}
	fmt.Println("  token rotated -> the dead worker's stale commit will now no-op")

	// committed is still pinned at lo while the reclaimed range is in-flight again
	committed = advance(ctx, cursorAdvancerDatastore, tp.Id)
	fmt.Printf("  roller tick (mid-reclaim) -> committed = %d\n", committed)
	assertInt64("committed still pinned during reclaim", committedCol(ctx, ds, tp.Id), claim1.Lease.Low)

	// the dead WORKER 1 "resurrects" and tries to commit with its STALE token: rejected
	if err := messageConsumers.Commit(ctx, tp.Id, groupId, claim1.Lease.Token, nil, 5*time.Second, stream.DeliveryLogModeFailures); !errors.Is(err, iCommon.ErrLeaseLost) {
		common.Die(fmt.Sprintf("stale commit: want ErrLeaseLost, got %v", err))
	}
	assertInt64("stale commit freed nothing (live lease survives)", leases(ctx, ds, tp.Id), 1)
	assertInt64("stale commit did not move committed", committedCol(ctx, ds, tp.Id), claim1.Lease.Low)
	fmt.Println("  dead worker's stale Commit was rejected with ErrLeaseLost")

	// WORKER 2 finishes the range for real -> free lease, roller advances
	common.Must(messageConsumers.Commit(ctx, tp.Id, groupId, claim2.Lease.Token, nil, 5*time.Second, stream.DeliveryLogModeFailures))
	committed = advance(ctx, cursorAdvancerDatastore, tp.Id)
	fmt.Printf("  reclaim committed -> roller tick -> committed = %d\n", committed)

	snapshot(ctx, ds, tp.Id, "AFTER RECLAIM COMMITTED")
	assertInt64("committed released past reclaimed range", committedCol(ctx, ds, tp.Id), claim1.Lease.High)
	assertInt64("crashed lease is gone", leases(ctx, ds, tp.Id), 0)
	assertInt64("still no exception rows", deliveries(ctx, ds, tp.Id), 0)

	// ===== drain the rest so committed reaches head =====
	step("drain remaining ranges -> committed reaches head")
	for range 10 {
		c, err := messageConsumers.ClaimMessagesWithCursor(ctx, tp.Id, groupId, 1, batch, maxRangeReclaims, lease, stream.DeliveryLogModeFailures)
		common.Must(err)
		if c == nil {
			break // caught up
		}
		common.Must(messageConsumers.Commit(ctx, tp.Id, groupId, c.Lease.Token, nil, 5*time.Second, stream.DeliveryLogModeFailures))
		fmt.Printf("  drained (%d,%d] -> committed = %d\n", c.Lease.Low, c.Lease.High, advance(ctx, cursorAdvancerDatastore, tp.Id))
	}
	assertInt64("committed reached head", committedCol(ctx, ds, tp.Id), head)
	assertInt64("no leases left open", leases(ctx, ds, tp.Id), 0)
	assertInt64("exception queue stayed empty the whole e2e test", deliveries(ctx, ds, tp.Id), 0)

	fmt.Println("\n✅ PHASE 6.5b E2E TEST PASSED")
	fmt.Println("   crash mid-range -> lease expired -> exact range reclaimed (token rotated) ->")
	fmt.Println("   reprocessed -> committed pinned at lo then jumped to head -> exception queue empty.")
	return nil
}

// ---- helpers ----

func advance(ctx context.Context, cursorAdvancerDatastore *cursoradvancerdatastore.CursorAdvancerDatastore, streamId int64) int64 {
	c, err := cursorAdvancerDatastore.AdvanceCommitted(ctx, streamId, groupId)
	common.Must(err)
	return c
}

func snapshot(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64, label string) {
	fmt.Printf("  [%s] committed=%d claimed=%d open_leases=%d deliveries=%d\n",
		label, committedCol(ctx, ds, streamId), claimedCol(ctx, ds, streamId), leases(ctx, ds, streamId), deliveries(ctx, ds, streamId))
}

func committedCol(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT committed FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ConsumerGroupCursorTable(streamId)), groupId)
}
func claimedCol(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT claimed FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ConsumerGroupCursorTable(streamId)), groupId)
}
func leases(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT count(*) FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ClaimLeaseTable(streamId)), groupId)
}
func deliveries(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT count(*) FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ExceptionQueueTable(streamId)), groupId)
}

func scalar(ctx context.Context, ds *iDatastore.PostgresDatastore, q string, args ...any) int64 {
	var v int64
	common.Must(ds.Pool.QueryRow(ctx, q, args...).Scan(&v))
	return v
}

func ids(msgs []messageconsumercontroller.Message) []int64 {
	out := make([]int64, len(msgs))
	for i, m := range msgs {
		out[i] = m.Id
	}
	return out
}

func shortTok[T fmt.Stringer](t T) string {
	s := t.String()
	if len(s) >= 8 {
		return s[:8]
	}
	return s
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
func assertInt64(label string, got, want int64) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", label, got, want))
	}
	fmt.Printf("  ✓ %s (%d)\n", label, got)
}

func mustGroupID(g *consume.Consumer, err error) int64 { common.Must(err); return g.Id }
