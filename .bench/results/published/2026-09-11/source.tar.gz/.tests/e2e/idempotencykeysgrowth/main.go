package main

// idempotency_key growth e2e test: quantifies the sustained-throughput/storage
// axis of the claim-gate tradeoff -- distinct from a per-call fixed-cost/
// round-trip measurement (that's a separate question), this asks: does the
// claim gate's steady-state size become a real production concern, and can
// the janitor's sweep actually keep pace with it?
//
// Two scenarios:
//   - Accumulation & relative overhead: publish with no sweep running,
//     snapshot idempotency_key_<id>'s size (a per-stream table, so no
//     cross-stream baseline subtraction needed) against this stream's own
//     message_log size at the same checkpoints -- puts "how much extra
//     storage" in concrete, relative terms instead of raw bytes.
//   - Sweep keep-up: sustained concurrent publishing WHILE the sweep runs
//     on the same cadence MessageConsumer's real Janitor loop uses (a ticker
//     firing SweepExpiredIdempotencyKeys at a fixed poll rate, batched) --
//     Little's Law says a keeping-up sweep should hold the table's
//     steady-state size near rate * ttl, not let it grow toward the full
//     count published; confirms that bound holds, and that a final pass
//     past ttl drains it to zero.
//
// Registers its own streams (destroyed on exit), self-seeded, self-verifying.

import (
	"context"
	"fmt"
	"github.com/agentstax/sqlstreams/pkg/stream"
	"os"
	"sync"
	"sync/atomic"
	"time"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	janitordatastore "github.com/agentstax/sqlstreams/pkg/stream/janitor/controller/datastore"
	"github.com/jackc/pgx/v5/pgxpool"
)

const largePartitionSize = int64(1_000_000) // never rolls -- partition churn isn't what's being measured

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, &sqlstreams.PostgresConnectionConfig{
		MaxConns: 50, // headroom above the keep-up scenario's 30 concurrent publishers + sweeper
	})
	common.Must(err)
	defer pool.Close()

	accumulationScenario(ctx, pool)
	sweepKeepUpScenario(ctx, pool)

	fmt.Println("\n✅ IDEMPOTENCY KEYS GROWTH E2E TEST -- numbers gathered, see the idempotency_key")
	fmt.Println("   tradeoff discussion for what they mean and whether they change anything.")
	return nil
}

// accumulationScenario: publish with the janitor never running, snapshot
// idempotency_key_<id>'s size against message_log's own size at the same
// checkpoints -- isolates "how much extra storage does the claim gate cost"
// from the separate question (next scenario) of whether the sweep keeps up.
func accumulationScenario(ctx context.Context, pool *pgxpool.Pool) {
	step("accumulation: idempotency_key_<id> size vs. message_log size, no sweep running")

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)

	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName := fmt.Sprintf("phase9.idempotencykeysgrowth.accum.%d", time.Now().UnixNano())
	tp, err := client.Stream[sqlstreams.RawPayload](streamName).Register(ctx, &sqlstreams.StreamConfig{PartitionSize: largePartitionSize, IdempotencyKeyTTL: time.Hour})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[sqlstreams.RawPayload](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)

	idkTable := fmt.Sprintf("%s.%s", ds.Schema, stream.IdempotencyKeyTable(tp.Id))

	checkpoints := []int{500, 2000, 5000}
	published := 0
	for _, target := range checkpoints {
		publishConcurrent(ctx, wpInstance, target-published, 20)
		published = target

		idkSize := tableByteSize(ctx, ds, idkTable)
		// message_log_<id> is a partitioned parent with no storage of its own --
		// its data lives in message_log_<id>_0 (largePartitionSize never rolls).
		logSize := tableByteSize(ctx, ds, fmt.Sprintf("%s.%s_0", ds.Schema, stream.MessageLogTable(tp.Id)))
		idkRows := tableRowCount(ctx, ds, idkTable)

		fmt.Printf("  %6d msgs: idempotency_key_%d=%-8s (%6d rows)  message_log=%8s  overhead=%.1f%%\n",
			published, tp.Id, humanBytes(idkSize), idkRows, humanBytes(logSize), pctOf(idkSize, logSize))
	}
}

// sweepKeepUpScenario: sustained concurrent publishing WHILE the sweep runs
// on the same cadence MessageConsumer's real Janitor loop uses (a ticker firing
// SweepExpiredIdempotencyKeys, batched) -- proves whether steady-state size
// stays bounded near rate * ttl (Little's Law) or the sweep falls behind and
// the table grows toward the full published count instead.
func sweepKeepUpScenario(ctx context.Context, pool *pgxpool.Pool) {
	step("sweep keep-up: sustained publish load concurrent with the real janitor cadence")

	const ttl = 200 * time.Millisecond
	const sweepPollRate = 50 * time.Millisecond
	const sweepBatchSize = 500
	const duration = 3 * time.Second
	const publishers = 30

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)

	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName := fmt.Sprintf("phase9.idempotencykeysgrowth.keepup.%d", time.Now().UnixNano())
	tp, err := client.Stream[sqlstreams.RawPayload](streamName).Register(ctx, &sqlstreams.StreamConfig{PartitionSize: largePartitionSize, IdempotencyKeyTTL: ttl})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[sqlstreams.RawPayload](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)
	janitorDatastore, err := janitordatastore.NewJanitorDatastore(ds, ds.Logger)
	common.Must(err)

	idkTable := fmt.Sprintf("%s.%s", ds.Schema, stream.IdempotencyKeyTable(tp.Id))

	stop := make(chan struct{})
	var published atomic.Int64

	// N goroutines publishing flat-out for `duration`
	var wg sync.WaitGroup
	for range publishers {
		wg.Go(func() {
			for {
				select {
				case <-stop:
					return
				default:
					_, err := wpInstance.ProduceFunc(ctx, func(ctx context.Context, tx sqlstreams.Tx) (*common.Work, error) {
						return common.NewWork(30, "admin@example.com")
					}, nil)
					common.Must(err)
					published.Add(1)
				}
			}
		})
	}

	// mirrors MessageConsumer.Janitor's own ticker + sweep call, same shape
	var sweepWg sync.WaitGroup
	var peakRows atomic.Int64
	sweepWg.Go(func() {
		ticker := time.NewTicker(sweepPollRate)
		defer ticker.Stop()
		for {
			select {
			case <-stop:
				return
			case <-ticker.C:
				common.Must(janitorDatastore.SweepExpiredIdempotencyKeys(ctx, tp.Id, ttl, sweepBatchSize))
				if rows := tableRowCount(ctx, ds, idkTable); rows > peakRows.Load() {
					peakRows.Store(rows)
				}
			}
		}
	})

	time.Sleep(duration)
	close(stop)
	wg.Wait()
	sweepWg.Wait()

	// one final sweep pass past ttl, so a fully-drained table proves the
	// sweep -- not just the test ending -- is what kept it bounded
	time.Sleep(ttl + 100*time.Millisecond)
	common.Must(janitorDatastore.SweepExpiredIdempotencyKeys(ctx, tp.Id, ttl, sweepBatchSize))
	finalRows := tableRowCount(ctx, ds, idkTable)

	total := published.Load()
	peak := peakRows.Load()
	rate := float64(total) / duration.Seconds()
	// Little's Law: rows in the system ~= arrival rate * time each stays --
	// a sweep keeping pace should hold steady-state near rate*ttl, not let
	// it climb toward the full published count.
	littlesLawEstimate := rate * ttl.Seconds()

	fmt.Printf("  published %d messages over %v (%.0f msg/sec)\n", total, duration, rate)
	fmt.Printf("  Little's Law estimate (rate * ttl): ~%.0f rows steady-state if the sweep keeps pace\n", littlesLawEstimate)
	fmt.Printf("  peak idempotency_key rows observed during the run: %d (vs. %d total published)\n", peak, total)
	fmt.Printf("  final idempotency_key rows after one more pass past ttl: %d\n", finalRows)

	if finalRows != 0 {
		common.Die(fmt.Sprintf("%s has %d rows after a full sweep pass past ttl, want 0", idkTable, finalRows))
	}
	// generous slop factor -- poll interval, batch granularity, and goroutine
	// scheduling jitter all push peak above the exact Little's Law point
	// estimate, but a keeping-up sweep should stay an order of magnitude
	// below "grew unboundedly toward everything ever published."
	bound := int64(littlesLawEstimate*10) + sweepBatchSize
	if peak > bound {
		common.Die(fmt.Sprintf("peak rows (%d) exceeded %dx the Little's Law estimate + one batch (%d) -- sweep fell behind publish load", peak, 10, bound))
	}
	if peak >= total {
		common.Die(fmt.Sprintf("peak rows (%d) reached the full published count (%d) -- sweep never got ahead of publish load", peak, total))
	}
	fmt.Println("  ✓ steady-state size stayed bounded near the Little's Law estimate, and drained to 0 once ttl passed")
}

// ---- helpers ----

func publishConcurrent(ctx context.Context, wpInstance *sqlstreams.ProducerInstance[common.Work], n, goroutines int) {
	perGoroutine := n / goroutines
	remainder := n % goroutines

	var wg sync.WaitGroup
	for g := range goroutines {
		count := perGoroutine
		if g < remainder {
			count++
		}
		wg.Go(func() {
			for range count {
				_, err := wpInstance.ProduceFunc(ctx, func(ctx context.Context, tx sqlstreams.Tx) (*common.Work, error) {
					return common.NewWork(30, "admin@example.com")
				}, nil)
				common.Must(err)
			}
		})
	}
	wg.Wait()
}

func tableByteSize(ctx context.Context, ds *iDatastore.PostgresDatastore, table string) int64 {
	var size int64
	common.Must(ds.Pool.QueryRow(ctx, `SELECT pg_total_relation_size($1::regclass);`, table).Scan(&size))
	return size
}

func tableRowCount(ctx context.Context, ds *iDatastore.PostgresDatastore, table string) int64 {
	var count int64
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT COUNT(*) FROM %s;`, table)).Scan(&count))
	return count
}

func pctOf(part, whole int64) float64 {
	if whole == 0 {
		return 0
	}
	return float64(part) / float64(whole) * 100
}

func humanBytes(b int64) string {
	switch {
	case b >= 1<<20:
		return fmt.Sprintf("%.1fMB", float64(b)/(1<<20))
	case b >= 1<<10:
		return fmt.Sprintf("%.1fKB", float64(b)/(1<<10))
	default:
		return fmt.Sprintf("%dB", b)
	}
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
