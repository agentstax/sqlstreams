package main

import (
	"context"
	"fmt"
	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	"github.com/agentstax/sqlstreams/pkg/datastore"
	"os"
	"time"

	metricscontroller "github.com/agentstax/sqlstreams/pkg/metric/controller"
	metricsproducer "github.com/agentstax/sqlstreams/pkg/metric/producer"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
)

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()
	run := time.Now().UnixNano()
	streamId := run // no real stream needs to exist -- the events just carry this id as data
	group := fmt.Sprintf("abandonedroutinesnapshot.%d", run)

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := datastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)
	common.Must(client.System().Register(ctx, nil))

	metricController, err := metricscontroller.NewMetricsController(ds, ds.Logger)
	common.Must(err)

	step("never-produced (stream, group) -> zeroes, not an error")
	snapshot, err := metricController.AbandonedRoutineSnapshot(ctx, streamId, group)
	common.Must(err)
	assertInt64("Total", snapshot.Total, 0)
	assertInt64("Outstanding", snapshot.Outstanding, 0)
	assertDuration("SelfClearLatencyAvg", snapshot.SelfClearLatencyAvg, 0)

	step("two producers (simulating two processes) interleave abandoned/cleared for the same group")
	producerA, err := metricsproducer.NewMetricsProducer(ds, &metricsproducer.MetricProducerConfig{SessionFlushRate: 100 * time.Millisecond}, ds.Logger)
	common.Must(err)
	go func() {
		common.Must(producerA.Run(ctx, group, "abandonedroutinesnapshot", 1, "session-a"))
	}()
	producerB, err := metricsproducer.NewMetricsProducer(ds, &metricsproducer.MetricProducerConfig{SessionFlushRate: 100 * time.Millisecond}, ds.Logger)
	common.Must(err)
	go func() {
		common.Must(producerB.Run(ctx, group, "abandonedroutinesnapshot", 1, "session-b"))
	}()

	producerA.RecordAbandoned(streamId, group, 1, 1) // matched pair, cleared by A
	producerB.RecordAbandoned(streamId, group, 2, 1) // matched pair, cleared by B
	time.Sleep(20 * time.Millisecond)                // let the self-clear latency be non-zero and measurable
	producerA.RecordCleared(streamId, group, 1, 1)
	producerB.RecordCleared(streamId, group, 2, 1)
	producerA.RecordAbandoned(streamId, group, 3, 1) // never cleared -- outstanding

	// events are produced off the hot path, landing on the next flush tick --
	// give them a moment to actually land
	common.Must(waitFor(10*time.Second, func() (bool, error) {
		s, err := metricController.AbandonedRoutineSnapshot(ctx, streamId, group)
		if err != nil {
			return false, err
		}
		return s.Total == 3, nil
	}))

	snapshot, err = metricController.AbandonedRoutineSnapshot(ctx, streamId, group)
	common.Must(err)
	assertInt64("Total", snapshot.Total, 3)
	assertInt64("Outstanding", snapshot.Outstanding, 1)
	if snapshot.SelfClearLatencyAvg <= 0 {
		common.Die(fmt.Sprintf("SelfClearLatencyAvg: expected > 0, got %v", snapshot.SelfClearLatencyAvg))
	}
	fmt.Printf("  ✓ SelfClearLatencyAvg (%v)\n", snapshot.SelfClearLatencyAvg)

	step("a different group on the same stream id sees none of the above")
	otherGroup := fmt.Sprintf("abandonedroutinesnapshot.other.%d", run)
	isolated, err := metricController.AbandonedRoutineSnapshot(ctx, streamId, otherGroup)
	common.Must(err)
	assertInt64("Total", isolated.Total, 0)
	assertInt64("Outstanding", isolated.Outstanding, 0)

	fmt.Println("\n✅ ABANDONED ROUTINE SNAPSHOT E2E TEST PASSED")
	return nil
}

func waitFor(timeout time.Duration, cond func() (bool, error)) error {
	deadline := time.Now().Add(timeout)
	for {
		ok, err := cond()
		if err != nil {
			return err
		}
		if ok {
			return nil
		}
		if time.Now().After(deadline) {
			return fmt.Errorf("timed out waiting for condition")
		}
		time.Sleep(50 * time.Millisecond)
	}
}

func assertInt64(label string, got, want int64) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", label, got, want))
	}
	fmt.Printf("  ✓ %s (%d)\n", label, got)
}

func assertDuration(label string, got, want time.Duration) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %v, want %v", label, got, want))
	}
	fmt.Printf("  ✓ %s (%v)\n", label, got)
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
