package main

// schema evolution bridge e2e test: the end-to-end proof of the payload-version
// design on one stream -- the reference implementation of the user-space
// BRIDGE pattern the library documents but doesn't ship a verb for.
//
// Scenario: one stream holds live keyed traffic written by a V1Order
// producer. The application evolves to V2Order (adds Currency). A bridge
// consumer group bound to V1Order reads each key's current head and
// re-produces it as V2Order at CompactionRank -1 (a backfill, never a live
// write), while the application's real producers write V2Order straight in
// at rank 0 for keys that have already cut over. Confirms, against the real
// claim/lease/cursor machinery, not just the SQL-level guarantee
// compactionrank proves in isolation:
//   - a v2 row always beats the key's v1 head: the compaction winner compares
//     (schema_version, compaction_rank, message_id), so the bridge's rank -1 copy
//     supersedes the v1 row it was made from.
//   - zero-pause: a key with a live rank-0 v2 write never loses to the
//     bridge's rank -1 copy of the same key, in EITHER arrival order (user:1
//     is live-before-bridge, user:2 is bridge-before-live). A key whose
//     head already moved to v2 before the bridge reached it (user:1) is
//     never bridged at all: its v1 row stopped being the head, so the claim
//     skips it as superseded.
//   - crash + restart: stopping the bridge mid-drain and starting a fresh
//     instance on the same consumer group resumes from the persisted cursor
//     instead of re-walking the log from the start, and the source-id-derived
//     IdempotencyKey means however that boundary message gets settled (clean
//     commit vs. redelivered), exactly one bridged row lands per key -- never
//     a duplicate. This e2e test picks a deterministic stop point (distinct-key
//     count, not a timer) to stay non-flaky; it is not trying to win a race
//     against an in-flight commit -- idempotencykeysrace already covers
//     dedup-under-true-concurrency.
//   - the retire verdict is a query: StreamHealth reports v1 safe once no
//     compaction head points at a v1 row and the bridge group has read past
//     every v1 row, and v2 not safe while the heads are at v2.
//
// Self-contained: registers the stream, destroys it on exit.

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	"github.com/agentstax/sqlstreams/pkg/stream"
	"os"
	"strconv"
	"sync/atomic"
	"time"

	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
)

const group = "phase14a.schemaevolution.bridge"

var keys = []string{"user:1", "user:2", "user:3", "user:4", "user:5"}

// V1Order is what the producers wrote before the schema evolved.
type V1Order struct {
	Key   string `json:"key"`
	Cents int64  `json:"cents"`
}

func (V1Order) SchemaVersion() int { return 1 }

// V2Order adds Currency -- the change the bridge exists to carry forward;
// rows the bridge itself writes default it to "USD".
type V2Order struct {
	Key      string `json:"key"`
	Cents    int64  `json:"cents"`
	Currency string `json:"currency"`
}

func (V2Order) SchemaVersion() int { return 2 }

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	name := fmt.Sprintf("phase14a.schemaevolution.%d", time.Now().UnixNano())
	registered, err := client.Stream[V1Order](name).Register(ctx, &sqlstreams.StreamConfig{})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[V1Order](name).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	wp1Instance, err := client.Stream[V1Order](name).Producer().Register(ctx, nil)
	common.Must(err)

	step("the stream holds live keyed V1Order traffic for 5 users")
	for i, key := range keys {
		cents := int64(i+1) * 100
		_, err := wp1Instance.Produce(ctx, &V1Order{Key: key, Cents: cents}, &sqlstreams.ProduceOptions{MessageKey: key, Compaction: &sqlstreams.CompactionOptions{Enable: true}})
		common.Must(err)
		fmt.Printf("  wrote %s cents=%d as V1Order\n", key, cents)
	}

	step("a V2Order producer registers on the same stream -- its rows carry schema_version 2")
	wp2Instance, err := client.Stream[V2Order](name).Producer().Register(ctx, nil)
	common.Must(err)

	step("user:1 cuts over to v2 BEFORE the bridge ever sees it (live-then-backfill)")
	common.Must(liveWrite(ctx, wp2Instance, "user:1", 999, "EUR"))

	// processed counts successful bridge writes; crashGate blocks the 3rd
	// message the bridge reaches (user:4 -- user:1 is already superseded)
	// until we've confirmed exactly 2 landed, then run1's
	// ctx is cancelled while it's mid-block -- a deterministic, DB-timing-
	// independent stand-in for "the process died right here."
	var processed atomic.Int64
	crashGate := make(chan struct{})
	bridgeFunc := func(ctx context.Context, work *V1Order) error {
		if processed.Load() >= 2 {
			select {
			case <-crashGate:
			case <-ctx.Done():
				return ctx.Err()
			}
		}

		meta, ok := sqlstreams.MetaFromContext(ctx)
		if !ok {
			return fmt.Errorf("no MessageMeta in context for key %q", work.Key)
		}
		_, err := wp2Instance.Produce(ctx, &V2Order{Key: work.Key, Cents: work.Cents, Currency: "USD"}, &sqlstreams.ProduceOptions{
			MessageKey:     work.Key,
			Compaction:     &sqlstreams.CompactionOptions{Enable: true, Rank: -1},
			IdempotencyKey: bridgeIdempotencyKey(meta.Id),
		})
		if err == nil {
			processed.Add(1)
		}
		return err
	}

	step("bridge run 1: skips superseded user:1, drains user:2 and user:3, then \"crashes\" mid-user:4")
	run1Ctx, cancelRun1 := context.WithCancel(ctx)
	go func() {
		for processed.Load() < 2 {
			time.Sleep(time.Millisecond)
		}
		cancelRun1()
	}()
	bridge1 := newBridgeConsumer(ctx, client, name)
	common.Must(bridge1.Consume(run1Ctx, bridgeFunc, bridgeConsumeOptions))
	assertInt("exactly 2 messages landed before the crash", processed.Load(), 2)

	step("user:2 cuts over to v2 AFTER the bridge already copied it (backfill-then-live)")
	common.Must(liveWrite(ctx, wp2Instance, "user:2", 888, "EUR"))
	close(crashGate) // release user:4, wherever it's stuck (fresh claim or a retried exception)

	step("bridge run 2: a fresh instance, same group, resumes from the persisted cursor")
	run2Ctx, cancelRun2 := context.WithCancel(ctx)
	bridge2 := newBridgeConsumer(ctx, client, name)
	go func() {
		common.Must(waitForCommitted(run2Ctx, ds, registered.Id, 10*time.Second, cancelRun2))
	}()
	common.Must(bridge2.Consume(run2Ctx, bridgeFunc, bridgeConsumeOptions))

	step("verify the winners: live always beats the bridge, regardless of which arrived first")
	assertWinner(ctx, ds, registered.Id, "user:1", 999, "EUR") // live arrived first, still wins
	assertWinner(ctx, ds, registered.Id, "user:2", 888, "EUR") // live arrived second, still wins
	assertWinner(ctx, ds, registered.Id, "user:3", 300, "USD") // bridge only
	assertWinner(ctx, ds, registered.Id, "user:4", 400, "USD") // bridge only
	assertWinner(ctx, ds, registered.Id, "user:5", 500, "USD") // bridge only

	step("verify exactly-once: the crash/restart never left a duplicate row")
	assertInt("5 v1 rows, 4 bridged v2 rows (user:1 was superseded before the bridge reached it), 2 live v2 rows", rowCount(ctx, ds, registered.Id), 11)
	assertInt("every v1 row still physically present -- superseded, never rewritten", rowCountAtVersion(ctx, ds, registered.Id, 1), 5)

	step("the retire verdict is a query: v1 safe, v2 not")
	health, err := client.Stream[V1Order](name).Health(ctx)
	common.Must(err)
	v1Health := versionHealth(health, 1)
	assertInt("no compaction head still points at a v1 row", v1Health.CompactionHeads, 0)
	assertTrue("v1 is safe to retire", v1Health.Safe)
	assertTrue("safe reason is unchanged", v1Health.Reason == "safe: no compaction head points at this version and every group has read past it")
	fmt.Printf("  verdict v1: %s\n", v1Health.Reason)
	v2Health := versionHealth(health, 2)
	assertInt("every key's head is a v2 row", v2Health.CompactionHeads, int64(len(keys)))
	assertTrue("v2 is not safe to retire", !v2Health.Safe)
	assertTrue("compaction reason is unchanged", v2Health.Reason == "compaction heads remain: 5 keys still resolve to this version")
	fmt.Printf("  verdict v2: %s\n", v2Health.Reason)

	step("new readers prevent retirement; compaction heads still take precedence")
	orders := client.Stream[V1Order](name)
	billing := orders.Consumer("schemaevolution.billing")
	_, err = billing.Register(ctx, nil)
	common.Must(err)
	audit := orders.Consumer("schemaevolution.audit")
	_, err = audit.Register(ctx, nil)
	common.Must(err)
	lagging, err := orders.Health(ctx)
	common.Must(err)
	assertInt("version count is unchanged", int64(len(lagging)), int64(len(health)))
	for i, version := range lagging {
		assertInt("version ordering is unchanged", int64(version.Version), int64(health[i].Version))
		assertInt("message count is unchanged", version.Messages, health[i].Messages)
		assertInt("stream identity is unchanged", version.Stream.Id, registered.Id)
	}
	laggingV1 := versionHealth(lagging, 1)
	assertTrue("unread v1 is unsafe", !laggingV1.Safe)
	assertTrue("lagging names follow snapshot order", laggingV1.Reason == "not drained: schemaevolution.audit, schemaevolution.billing")
	laggingV2 := versionHealth(lagging, 2)
	assertTrue("v2 compaction heads take precedence over unread rows", !laggingV2.Safe && laggingV2.Reason == v2Health.Reason)

	fmt.Println("\n✅ SCHEMA EVOLUTION BRIDGE E2E TEST PASSED")
	fmt.Println("   a v2 row beats the v1 head -> live writes beat the bridge in either arrival order ->")
	fmt.Println("   a crashed bridge resumes from its cursor with no duplicates -> the retire verdict")
	fmt.Println("   reads the log instead of guessing.")
	return nil
}

// ---- helpers ----

func liveWrite(ctx context.Context, wp *sqlstreams.ProducerInstance[V2Order], key string, cents int64, currency string) error {
	_, err := wp.Produce(ctx, &V2Order{Key: key, Cents: cents, Currency: currency}, &sqlstreams.ProduceOptions{MessageKey: key, Compaction: &sqlstreams.CompactionOptions{Enable: true}})
	return err
}

// bridgeIdempotencyKey derives the bridge's key from the source message id,
// so a restarted bridge re-producing the same source message dedups.
func bridgeIdempotencyKey(sourceID int64) string {
	return "bridge." + strconv.FormatInt(sourceID, 10)
}

// newBridgeConsumer builds a fresh Consumer instance on the bridge's group --
// a new one each call, exactly as if the process had restarted. A short
// ExceptionInitialBackoff keeps the crash/retry path fast instead of waiting
// out the library's production-sized defaults; the session knobs are
// bridgeConsumeOptions.
func newBridgeConsumer(ctx context.Context, client *sqlstreams.Client, name string) *sqlstreams.ConsumerInstance[V1Order] {
	cInstance, err := client.Stream[V1Order](name).Consumer(group).Register(ctx, &sqlstreams.ConsumerConfig{
		Message:                 &sqlstreams.MessageOptions{Timeout: 2 * time.Second},
		ExceptionInitialBackoff: 200 * time.Millisecond,
	})

	common.Must(err)
	return cInstance
}

// bridgeConsumeOptions - BatchLimit 1 and a single-permit pool keep the
// bridge's own delivery order deterministic (ascending v1 id), so this e2e test's
// stop points are reproducible; short margins keep the crash/retry path fast.
var bridgeConsumeOptions = &sqlstreams.ConsumeOptions{
	BatchLimit:              1,
	QueueSize:               4,
	MessageConcurrency:      1,
	ClaimPollRate:           50 * time.Millisecond,
	QueueMargin:             500 * time.Millisecond,
	RecordMargin:            500 * time.Millisecond,
	DisableGracefulShutdown: true,
}

// waitForCommitted polls the bridge group's cursor until committed has
// passed the last v1 row -- a durable, DB-observed stop signal instead of a
// timer, taken after the commit so the retire verdict below reads a settled
// cursor.
func waitForCommitted(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64, timeout time.Duration, stop context.CancelFunc) error {
	lastV1 := scalar(ctx, ds, fmt.Sprintf(`SELECT max(id) FROM %s.%s WHERE schema_version = 1;`, ds.Schema, stream.MessageLogTable(streamId)))
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if committed(ctx, ds, streamId) >= lastV1 {
			stop()
			return nil
		}
		select {
		case <-ctx.Done():
			return nil // ctx already stopped some other way
		case <-time.After(20 * time.Millisecond):
		}
	}
	common.Die(fmt.Sprintf("timed out waiting for the bridge's committed cursor to reach %d", lastV1))
	return nil
}

func versionHealth(all []*sqlstreams.StreamVersionHealth, version int) *sqlstreams.StreamVersionHealth {
	for _, h := range all {
		if h.Version == version {
			return h
		}
	}
	common.Die(fmt.Sprintf("no StreamVersionHealth entry for version %d", version))
	return nil
}

func committed(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`
		SELECT c.committed FROM %s.%s c
		JOIN %s.consumer_group_config g ON g.id = c.consumer_group_id
		WHERE g.name = $1;`, ds.Schema, stream.ConsumerGroupCursorTable(streamId), ds.Schema), group)
}

func rowCount(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT count(*) FROM %s.%s`, ds.Schema, stream.MessageLogTable(streamId)))
}

func rowCountAtVersion(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64, version int64) int64 {
	return scalar(ctx, ds, fmt.Sprintf(`SELECT count(*) FROM %s.%s WHERE schema_version = $1`, ds.Schema, stream.MessageLogTable(streamId)), version)
}

func winner(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64, key string) *V2Order {
	var payload []byte
	err := ds.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT m.payload FROM %s.%s ch JOIN %s.%s m ON m.id = ch.message_id WHERE ch.compaction_key=$1;`, ds.Schema, stream.CompactionHeadTable(streamId), ds.Schema, stream.MessageLogTable(streamId)),
		key).Scan(&payload)
	common.Must(err)
	var v V2Order
	common.Must(json.Unmarshal(payload, &v))
	return &v
}

func scalar(ctx context.Context, ds *iDatastore.PostgresDatastore, q string, args ...any) int64 {
	var v int64
	common.Must(ds.Pool.QueryRow(ctx, q, args...).Scan(&v))
	return v
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
func assertInt(label string, got, want int64) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", label, got, want))
	}
	fmt.Printf("  ✓ %s (%d)\n", label, got)
}
func assertTrue(label string, cond bool) {
	if !cond {
		common.Die(fmt.Sprintf("%s: got false, want true", label))
	}
	fmt.Printf("  ✓ %s\n", label)
}
func assertWinner(ctx context.Context, ds *iDatastore.PostgresDatastore, streamId int64, key string, wantCents int64, wantCurrency string) {
	got := winner(ctx, ds, streamId, key)
	if got.Cents != wantCents || got.Currency != wantCurrency {
		common.Die(fmt.Sprintf("%s winner: got {%d %s}, want {%d %s}", key, got.Cents, got.Currency, wantCents, wantCurrency))
	}
	fmt.Printf("  ✓ %s winner is {%d %s}\n", key, got.Cents, got.Currency)
}
