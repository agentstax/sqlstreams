package main

// routing e2e test: confirms bindings gate what a group receives, not what gets claimed.
//
// Registers its own stream, destroyed on exit, so every run starts from a
// genuinely empty log -- no routing-key namespacing needed to dodge leftover
// rows from earlier runs (a trick the pre-8b shared-message_log version needed
// and this one doesn't).
//
// Drives the real datastore methods directly (DeclareBindings, ClaimMessagesWithCursor,
// FanOut, ClaimMessagesWithLifecycle) so matching is deterministic and asserted on
// exact returned rows, not inferred from timing.
//
// Confirms: a binding added AFTER a message already exists still applies to it the
// next time it's read (the predicate runs at claim/fan-out time, not publish
// time); a true wildcard crosses hierarchy depth (`orders.*.created` also
// matches `orders.us.central1.created`); the CURSOR path excludes
// non-matching rows from what's returned but still advances committed over the
// whole range; the LIFECYCLE path excludes them from ever getting a delivery
// row at all; and one group's binding has zero effect on another group reading
// the identical range.

import (
	"context"
	"fmt"
	"os"
	"time"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	"github.com/agentstax/sqlstreams/pkg/consume"
	consumecontroller "github.com/agentstax/sqlstreams/pkg/consume/controller"
	cursoradvancerdatastore "github.com/agentstax/sqlstreams/pkg/consume/cursoradvancer/controller/datastore"
	deliveryconsumercontroller "github.com/agentstax/sqlstreams/pkg/consume/deliveryconsumer/controller"
	messageconsumercontroller "github.com/agentstax/sqlstreams/pkg/consume/messageconsumer/controller"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
	"github.com/agentstax/sqlstreams/pkg/stream"
)

const (
	cursorGroup    = "phase7.cursor.e2e"
	controlGroup   = "phase7.control.e2e"
	lifecycleGroup = "phase7.lifecycle.e2e"
)

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, nil)
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	streamName := fmt.Sprintf("phase7.routing.%d", time.Now().UnixNano())
	tp, err := client.Stream[sqlstreams.RawPayload](streamName).Register(ctx, &sqlstreams.StreamConfig{})
	common.Must(err)
	defer func() {
		common.Must(client.Stream[sqlstreams.RawPayload](streamName).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}()

	cd, err := consumecontroller.NewConsumeController(ds, ds.Logger)
	common.Must(err)
	messageConsumers, err := messageconsumercontroller.NewMessageConsumerGroupController(ds, ds.Logger)
	common.Must(err)
	deliveryConsumers, err := deliveryconsumercontroller.NewDeliveryConsumerGroupController(ds, ds.Logger)
	common.Must(err)
	cursorAdvancerDatastore, err := cursoradvancerdatastore.NewCursorAdvancerDatastore(ds, ds.Logger)
	common.Must(err)
	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)

	head, gids := reset(ctx, ds, cd, tp.Id, cursorGroup, controlGroup, lifecycleGroup)
	cursorGroupID, controlGroupID, lifecycleGroupID := gids[cursorGroup], gids[controlGroup], gids[lifecycleGroup]
	fmt.Printf("stream=%q id=%d message_log head = %d\n", streamName, tp.Id, head)

	// ===== publish msg1 BEFORE any binding exists =====
	step("publish msg1, no binding exists for any group yet")
	msg1 := publish(ctx, wpInstance, "orders.us.created")
	fmt.Printf("  published %s\n", msg1)

	// ===== bind cursorGroup and lifecycleGroup, THEN publish the rest =====
	step("bind cursorGroup to orders.*.created, lifecycleGroup to payments.*")
	_, err = cd.DeclareBindings(ctx, tp.Id, cursorGroupID, []string{"orders.*.created"}, time.Now())
	common.Must(err)
	_, err = cd.DeclareBindings(ctx, tp.Id, lifecycleGroupID, []string{"payments.*"}, time.Now())
	common.Must(err)

	msg2 := publish(ctx, wpInstance, "orders.us.central1.created") // deeper hierarchy, still matches (true wildcard)
	msg3 := publish(ctx, wpInstance, "orders.eu.updated")          // wrong tail, does not match
	msg4 := publish(ctx, wpInstance, "payments.charge")            // matches lifecycleGroup only
	msg5 := publish(ctx, wpInstance, "")                           // NULL routing_key, matches nothing bound
	fmt.Printf("  published %s\n  published %s\n  published %s\n  published %s\n", msg2, msg3, msg4, msg5)

	const lease = 5 * time.Second
	const limit = 10
	const maxRangeReclaims = 3 // never hit in this e2e test -- no crashed/reclaimed ranges here

	// ===== CURSOR path: cursorGroup only sees the 2 matching messages =====
	step("cursorGroup claims (head, head+5] -- expect only msg1 and msg2 back")
	claim, err := messageConsumers.ClaimMessagesWithCursor(ctx, tp.Id, cursorGroupID, 1, limit, maxRangeReclaims, lease, stream.DeliveryLogModeFailures)
	common.Must(err)
	if claim == nil {
		common.Die("expected a fresh claim, got nil (no work?)")
	}
	fmt.Printf("  claimed (%d,%d]  ids=%v\n", claim.Lease.Low, claim.Lease.High, ids(claim.Messages))
	assertInt("range low is head", claim.Lease.Low, head)
	assertInt("range high covers all 5 published", claim.Lease.High, head+5)
	assertIDs("only msg1 (published before the binding existed) and msg2 (deeper hierarchy) match",
		ids(claim.Messages), []int64{head + 1, head + 2})

	common.Must(messageConsumers.Commit(ctx, tp.Id, cursorGroupID, claim.Lease.Token, nil, 5*time.Second, stream.DeliveryLogModeFailures))
	committed := advance(ctx, cursorAdvancerDatastore, tp.Id, cursorGroupID)
	assertInt("committed advances over the WHOLE range regardless of match", committed, head+5)

	// ===== CURSOR path: controlGroup has no binding, sees every message =====
	step("controlGroup claims the identical range -- expect all 5 back, unaffected by cursorGroup's binding")
	claim, err = messageConsumers.ClaimMessagesWithCursor(ctx, tp.Id, controlGroupID, 1, limit, maxRangeReclaims, lease, stream.DeliveryLogModeFailures)
	common.Must(err)
	if claim == nil {
		common.Die("expected a fresh claim, got nil (no work?)")
	}
	fmt.Printf("  claimed (%d,%d]  ids=%v\n", claim.Lease.Low, claim.Lease.High, ids(claim.Messages))
	assertIDs("an unbound group receives every message, including the NULL routing_key one",
		ids(claim.Messages), []int64{head + 1, head + 2, head + 3, head + 4, head + 5})

	common.Must(messageConsumers.Commit(ctx, tp.Id, controlGroupID, claim.Lease.Token, nil, 5*time.Second, stream.DeliveryLogModeFailures))
	advance(ctx, cursorAdvancerDatastore, tp.Id, controlGroupID)

	// ===== LIFECYCLE path: only a matching message ever gets a delivery row =====
	step("FanOut lifecycleGroup -- expect exactly 1 delivery row (msg4, payments.charge)")
	common.Must(deliveryConsumers.FanOut(ctx, tp.Id, lifecycleGroupID, 1, 100))
	deliveries, err := deliveryConsumers.ClaimMessagesWithLifecycle(ctx, tp.Id, lifecycleGroupID, limit)
	common.Must(err)
	fmt.Printf("  claimed deliveries: %v\n", deliveryIDs(deliveries))
	assertIDs("payments.charge is the only message materialized as a delivery",
		deliveryIDs(deliveries), []int64{head + 4})

	fmt.Println("\n✅ ROUTING E2E TEST PASSED")
	fmt.Println("   binding predicate applies at claim/fan-out time, not publish time -> true wildcard")
	fmt.Println("   crosses hierarchy depth -> CURSOR path filters what's returned but still advances the")
	fmt.Println("   full range -> LIFECYCLE path never materializes a row for a non-match at all.")
	return nil
}

// ---- helpers ----

func publish(ctx context.Context, wpInstance *sqlstreams.ProducerInstance[common.Work], routingKey string) string {
	produced, err := wpInstance.ProduceFunc(ctx, func(ctx context.Context, tx sqlstreams.Tx) (*common.Work, error) {
		return common.NewWork(30, "admin@example.com")
	}, &sqlstreams.ProduceOptions{RoutingKey: routingKey})
	common.Must(err)
	return fmt.Sprintf("work=%s routing_key=%q", produced.Message.Id, routingKey)
}

// resets all three groups to a clean slate and fast-forwards their cursors to
// the current log head, so a fresh CURSOR claim only ever sees messages this
// e2e test itself publishes.
func reset(ctx context.Context, ds *iDatastore.PostgresDatastore, cd *consumecontroller.ConsumeController, streamId int64, groups ...string) (int64, map[string]int64) {
	head := scalar(ctx, ds, fmt.Sprintf(`SELECT COALESCE(max(id),0) FROM %s.%s`, ds.Schema, stream.MessageLogTable(streamId)))
	gids := map[string]int64{}
	for _, g := range groups {
		gID := mustGroupID(cd.RegisterGroup(ctx, streamId, g, consume.Beginning()))
		gids[g] = gID
		_, err := ds.Pool.Exec(ctx, fmt.Sprintf(`DELETE FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ClaimLeaseTable(streamId)), gID)
		common.Must(err)
		_, err = ds.Pool.Exec(ctx, fmt.Sprintf(`DELETE FROM %s.%s WHERE consumer_group_id=$1`, ds.Schema, stream.ExceptionQueueTable(streamId)), gID)
		common.Must(err)
		_, err = cd.DeclareBindings(ctx, streamId, gID, nil, time.Now())
		common.Must(err)
		// settled/pending must ride along -- the claim gate assumes
		// gate >= settled >= claimed; bumping claimed alone breaks that and a
		// poll where the fresh pair doesn't prove would regress the cursor
		_, err = ds.Pool.Exec(ctx, fmt.Sprintf(`UPDATE %s.%s SET claimed=$2, committed=$2, settled_head=$2, pending_head=$2, pending_xid=NULL WHERE consumer_group_id=$1`, ds.Schema, stream.ConsumerGroupCursorTable(streamId)), gID, head)
		common.Must(err)
	}
	return head, gids
}

func advance(ctx context.Context, cursorAdvancerDatastore *cursoradvancerdatastore.CursorAdvancerDatastore, streamId int64, groupId int64) int64 {
	c, err := cursorAdvancerDatastore.AdvanceCommitted(ctx, streamId, groupId)
	common.Must(err)
	return c
}

func scalar(ctx context.Context, ds *iDatastore.PostgresDatastore, q string, args ...any) int64 {
	var v int64
	common.Must(ds.Pool.QueryRow(ctx, q, args...).Scan(&v))
	return v
}

func ids(msgs []messageconsumercontroller.Message) []int64 {
	out := make([]int64, len(msgs))
	for i, m := range msgs {
		out[i] = m.Id
	}
	return out
}

func deliveryIDs(rows []deliveryconsumercontroller.Delivery) []int64 {
	out := make([]int64, len(rows))
	for i, r := range rows {
		out[i] = r.MessageId
	}
	return out
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }
func assertInt(label string, got, want int64) {
	if got != want {
		common.Die(fmt.Sprintf("%s: got %d, want %d", label, got, want))
	}
	fmt.Printf("  ✓ %s (%d)\n", label, got)
}
func assertIDs(label string, got, want []int64) {
	if len(got) != len(want) {
		common.Die(fmt.Sprintf("%s: got %v, want %v", label, got, want))
	}
	for i := range got {
		if got[i] != want[i] {
			common.Die(fmt.Sprintf("%s: got %v, want %v", label, got, want))
		}
	}
	fmt.Printf("  ✓ %s %v\n", label, got)
}

func mustGroupID(g *consume.Consumer, err error) int64 { common.Must(err); return g.Id }
