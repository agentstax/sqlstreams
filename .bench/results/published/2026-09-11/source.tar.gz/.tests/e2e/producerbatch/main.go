package main

// Producer batching acceptance e2e test: the permanent home for what the
// throwaway in-package batcher harness verified, driven entirely through
// the public API. Six scenarios:
//
//   - batchedExactlyOnceScenario: N concurrent callers through payload-only
//     Produce all land exactly once (messages AND claim rows), xmin grouping
//     proves calls actually shared transactions, and a caller-keyed Produce
//     routes to the per-call path and dedups across its own retries.
//   - produceBatchScenario: one explicit ProduceBatch call commits every
//     item in ONE transaction (single xmin) with results in argument order;
//     a poisoned item rolls the whole batch back, naming its index; caller
//     keys and empty batches are rejected.
//   - faultIsolationScenario: one server-side-poisoned payload (jsonb
//     rejects \u0000) and one client-side-unencodable payload each fail ONLY
//     their own caller -- everyone sharing their batches still lands.
//   - hotCompactedKeysScenario: hot compacted message keys inside concurrent
//     batches -- the per-batch key sort keeps compaction_head lock order global,
//     so nothing deadlocks and every compaction_head row ends at its key's max id.
//   - partitionHealScenario: a burst that outruns the janitor's create-ahead
//     (no janitor running at all here) self-heals missing partitions,
//     sequentially and under concurrency.
//   - throughputScenario: the numbers -- batched Produce vs per-call
//     ProduceFunc at equal concurrency, plus a saturated batched arm
//     (callers >> batch cap). The retired SkipIdempotency floor's numbers
//     live in .bench/idempotency/RESULTS.md's follow-up section -- batched
//     lapped it ~10x saturated, which is why it could be removed.

import (
	"context"
	"fmt"
	"github.com/agentstax/sqlstreams/pkg/stream"
	"os"
	"strings"
	"sync"
	"time"
	"uuid"

	"github.com/agentstax/sqlstreams/.tests/e2e/common"
	iDatastore "github.com/agentstax/sqlstreams/pkg/datastore"
	sqlstreams "github.com/agentstax/sqlstreams/pkg/sqlstreams"
)

const largePartitionSize = int64(1_000_000) // never rolls -- partition churn is its own scenario

func main() {
	if err := run(); err != nil {
		fmt.Printf("\n❌ E2E TEST FAILED: %s\n", err.Error())
		os.Exit(1)
	}
}

func run() (err error) {
	defer common.Recover(&err)
	ctx := context.Background()

	pool, err := common.NewPool(ctx, &sqlstreams.PostgresConnectionConfig{
		MaxConns: 60, // headroom above the per-call arms' 50 concurrent publishers -- batched callers wait on a channel, not a connection, so even the 800-caller saturated arm needs no more
	})
	common.Must(err)
	defer pool.Close()

	client, err := sqlstreams.NewClient(ctx, pool, &sqlstreams.ClientConfig{AllowDestroy: true})
	common.Must(err)
	ds, err := iDatastore.NewPostgresDatastore(ctx, pool, nil)
	common.Must(err)

	batchedExactlyOnceScenario(ctx, client, ds)
	produceBatchScenario(ctx, client, ds)
	faultIsolationScenario(ctx, client, ds)
	hotCompactedKeysScenario(ctx, client, ds)
	partitionHealScenario(ctx, client, ds)
	throughputScenario(ctx, client, ds)

	fmt.Println("\n✅ PRODUCER BATCH E2E TEST PASSED")
	fmt.Println("   Concurrent payload-only Produce calls share transactions and land exactly")
	fmt.Println("   once, poisoned payloads fail only their own caller, hot compaction keys")
	fmt.Println("   never deadlock, bursts self-heal missing partitions, and the throughput")
	fmt.Println("   numbers above show what batching buys over the per-call paths.")
	return nil
}

// batchedExactlyOnceScenario: 50 goroutines x 20 payload-only Produce calls
// -- every one must land exactly once (message + claim row), and xmin
// grouping must show multi-row transactions, or "batching" never happened.
func batchedExactlyOnceScenario(ctx context.Context, client *sqlstreams.Client, ds *iDatastore.PostgresDatastore) {
	step("batched exactly-once: concurrent Produce calls share txns, land once each")

	const producers, msgs = 50, 20
	tp, client, cleanup := registerStream(ctx, client, "exactlyonce", largePartitionSize)
	defer cleanup()

	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)

	produceConcurrently(producers, msgs, func(p, s int) error {
		work, err := common.NewWork(30, "admin@example.com")
		if err != nil {
			return err
		}
		_, err = wpInstance.Produce(ctx, work, nil)
		return err
	})

	total := producers * msgs
	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id)), total, fmt.Sprintf("%d concurrent batched publishes all landed", total))
	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.IdempotencyKeyTable(tp.Id)), total, "every batched publish wrote its own claim row")

	// rows committed by one txn share xmin -- any multi-row xmin proves grouping
	var sharedTxns, largestBatch int
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`
		SELECT count(*), COALESCE(max(c), 0) FROM (
			SELECT count(*) AS c FROM %s.%s GROUP BY xmin HAVING count(*) > 1
		) shared;
	`, ds.Schema, stream.MessageLogTable(tp.Id))).Scan(&sharedTxns, &largestBatch))
	if sharedTxns == 0 {
		common.Die("no shared transactions observed -- 50 concurrent callers never grouped into a batch")
	}
	fmt.Printf("  ✓ calls genuinely shared transactions (%d shared txns, largest batch %d)\n", sharedTxns, largestBatch)

	// caller-keyed calls leave the batch: same key twice = one message
	key := uuid.NewV7().String()
	for range 2 {
		work, err := common.NewWork(31, "keyed@example.com")
		common.Must(err)
		_, err = wpInstance.Produce(ctx, work, &sqlstreams.ProduceOptions{IdempotencyKey: key})
		common.Must(err)
	}
	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id)), total+1, "a caller-keyed Produce routed per-call and deduped its retry")
}

// produceBatchScenario: the explicit batch verb -- unlike the batcher's
// collapsed singles, the caller hands over the whole batch and gets
// all-or-nothing back.
func produceBatchScenario(ctx context.Context, client *sqlstreams.Client, ds *iDatastore.PostgresDatastore) {
	step("ProduceBatch: one transaction, argument order, all-or-nothing")

	const total = 30
	tp, client, cleanup := registerStream(ctx, client, "producebatch", largePartitionSize)
	defer cleanup()

	wpInstance, err := client.Stream[rawPayload](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)

	items := make([]*sqlstreams.ProduceItem[rawPayload], 0, total)
	for s := range total {
		payload := rawPayload(fmt.Sprintf(`{"seq": %d}`, s))
		item, err := sqlstreams.NewProduceItem(&payload, nil)
		common.Must(err)
		items = append(items, item)
	}
	results, err := wpInstance.ProduceBatch(ctx, items...)
	common.Must(err)
	if len(results) != total {
		common.Die(fmt.Sprintf("want %d results, got %d", total, len(results)))
	}
	for s := 1; s < len(results); s++ {
		if results[s].Id <= results[s-1].Id {
			common.Die(fmt.Sprintf("result %d id %d not after result %d id %d -- argument order broken", s, results[s].Id, s-1, results[s-1].Id))
		}
	}
	fmt.Println("  ✓ ids strictly ascending in argument order")
	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id)), total, "every item landed")

	var txns int
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT count(DISTINCT xmin::text) FROM %s.%s;`, ds.Schema, stream.MessageLogTable(tp.Id))).Scan(&txns))
	if txns != 1 {
		common.Die(fmt.Sprintf("batch spread across %d transactions, want 1", txns))
	}
	fmt.Printf("  ✓ all %d rows share one transaction\n", total)

	// all-or-nothing: item 2 is rejected server-side (jsonb refuses \u0000),
	// so items 0-1 that already appended must roll back with it
	badItems := make([]*sqlstreams.ProduceItem[rawPayload], 0, 5)
	for s := range 5 {
		payload := rawPayload(fmt.Sprintf(`{"seq": %d}`, s))
		if s == 2 {
			payload = rawPayload(`{"seq": "\u0000"}`)
		}
		item, err := sqlstreams.NewProduceItem(&payload, nil)
		common.Must(err)
		badItems = append(badItems, item)
	}
	_, err = wpInstance.ProduceBatch(ctx, badItems...)
	if err == nil {
		common.Die("a batch with a poisoned item committed")
	}
	if !strings.Contains(err.Error(), "item 2") {
		common.Die(fmt.Sprintf("batch error must name the failed item, got: %v", err))
	}
	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id)), total, "the poisoned batch rolled back whole -- nothing landed")

	// caller keys are single-Produce-only; an empty batch is a usage error
	keyedPayload := rawPayload(`{"seq": 0}`)
	if _, err := sqlstreams.NewProduceItem(&keyedPayload, &sqlstreams.ProduceOptions{IdempotencyKey: uuid.NewV7().String()}); err == nil {
		common.Die("NewProduceItem accepted a caller IdempotencyKey")
	}
	if _, err := wpInstance.ProduceBatch(ctx); err == nil {
		common.Die("an empty ProduceBatch did not error")
	}
	fmt.Println("  ✓ caller IdempotencyKey and empty batch rejected")
}

// faultIsolationScenario: 20 concurrent produces where payload 7 is rejected
// server-side (jsonb refuses \u0000 -- poisons every rerun, evicted by
// statement index) and payload 13 fails client-side before anything is sent
// (batch splits to singles) -- each error reaches ONLY its own caller.
func faultIsolationScenario(ctx context.Context, client *sqlstreams.Client, ds *iDatastore.PostgresDatastore) {
	step("fault isolation: a bad payload fails its caller, never its batchmates")

	const total = 20
	const poisonSeq, brokenSeq = 7, 13
	tp, client, cleanup := registerStream(ctx, client, "faults", largePartitionSize)
	defer cleanup()

	wpInstance, err := client.Stream[rawPayload](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)

	errs := make([]error, total)
	var wg sync.WaitGroup
	for s := range total {
		wg.Go(func() {
			payload := rawPayload(fmt.Sprintf(`{"seq": %d}`, s))
			switch s {
			case poisonSeq:
				payload = rawPayload(`{"seq": "\u0000"}`)
			case brokenSeq:
				payload = rawPayload(`{"broken`)
			}
			_, errs[s] = wpInstance.Produce(ctx, &payload, nil)
		})
	}
	wg.Wait()

	for s, err := range errs {
		switch s {
		case poisonSeq, brokenSeq:
			if err == nil {
				common.Die(fmt.Sprintf("bad payload %d produced without error", s))
			}
		default:
			if err != nil {
				common.Die(fmt.Sprintf("good payload %d caught its batchmate's error: %v", s, err))
			}
		}
	}
	fmt.Println("  ✓ both bad payloads errored, all good payloads did not")
	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id)), total-2, "every good payload landed despite sharing batches with the bad ones")
}

// hotCompactedKeysScenario: 20 goroutines x 20 keyed produces across only 3
// hot keys, with a tiny batch cap so multiple workers commit concurrently --
// real cross-batch compaction_head contention. A deadlock would surface as an
// evicted operation's error; zero errors + every compaction_head row at its key's
// max id is the pass.
func hotCompactedKeysScenario(ctx context.Context, client *sqlstreams.Client, ds *iDatastore.PostgresDatastore) {
	step("hot compacted keys: concurrent batches contend on compaction_head without deadlock")

	const producers, msgs, keys = 20, 20, 3
	tp, client, cleanup := registerStream(ctx, client, "hotkeys", largePartitionSize)
	defer cleanup()

	// tiny cap -> backlog pressure -> concurrent workers -> real lock contention
	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, &sqlstreams.ProducerConfig{Batch: sqlstreams.BatcherConfig{MaxSize: 5}})
	common.Must(err)

	produceConcurrently(producers, msgs, func(p, s int) error {
		work, err := common.NewWork(30, "admin@example.com")
		if err != nil {
			return err
		}
		_, err = wpInstance.Produce(ctx, work, &sqlstreams.ProduceOptions{MessageKey: fmt.Sprintf("hot:%d", (p+s)%keys), Compaction: &sqlstreams.CompactionOptions{Enable: true}})
		return err
	})

	total := producers * msgs
	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id)), total, fmt.Sprintf("%d hot-keyed publishes all landed, none deadlocked", total))

	var stale int
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`
		SELECT count(*) FROM %s.%s lk
		JOIN (
			SELECT message_key, max(id) AS max_id FROM %s.%s GROUP BY message_key
		) m ON m.message_key = lk.compaction_key
		WHERE lk.message_id <> m.max_id;
	`, ds.Schema, stream.CompactionHeadTable(tp.Id), ds.Schema, stream.MessageLogTable(tp.Id))).Scan(&stale))
	if stale != 0 {
		common.Die(fmt.Sprintf("%d compaction_head rows not pointing at their key's max id", stale))
	}
	fmt.Printf("  ✓ every compaction_head row points at its key's max id across %d hot keys\n", keys)
}

// partitionHealScenario: PartitionSize 10 and no janitor, so produces past
// partition 0 MUST self-heal -- first sequentially (head advances one heal at
// a time), then as a concurrent burst.
func partitionHealScenario(ctx context.Context, client *sqlstreams.Client, ds *iDatastore.PostgresDatastore) {
	step("partition heal: a burst past the create-ahead self-heals, no janitor running")

	tp, client, cleanup := registerStream(ctx, client, "heal", 10)
	defer cleanup()

	// a batch of 5 can straddle a 10-row boundary: the rerun heals a second time
	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, &sqlstreams.ProducerConfig{Batch: sqlstreams.BatcherConfig{MaxSize: 5}})
	common.Must(err)

	for range 15 {
		work, err := common.NewWork(30, "admin@example.com")
		common.Must(err)
		_, err = wpInstance.Produce(ctx, work, nil)
		common.Must(err)
	}
	produceConcurrently(8, 5, func(p, s int) error {
		work, err := common.NewWork(30, "admin@example.com")
		if err != nil {
			return err
		}
		_, err = wpInstance.Produce(ctx, work, nil)
		return err
	})

	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id)), 55, "all 55 publishes landed across self-healed partitions")
}

// throughputScenario: the same workload down both paths -- how much the
// shared-transaction fsync amortization buys over per-call commits, at equal
// concurrency and then saturated.
func throughputScenario(ctx context.Context, client *sqlstreams.Client, ds *iDatastore.PostgresDatastore) {
	step("throughput: batched Produce vs per-call ProduceFunc, then saturated")

	const producers, msgs = 50, 400 // ~2s per arm -- sub-second runs are all warmup noise
	total := producers * msgs

	batched := timeArm(ctx, client, ds, "batched", producers, msgs, func(wpInstance *sqlstreams.ProducerInstance[common.Work], work *common.Work) error {
		_, err := wpInstance.Produce(ctx, work, nil)
		return err
	})
	perCall := timeArm(ctx, client, ds, "percall", producers, msgs, func(wpInstance *sqlstreams.ProducerInstance[common.Work], work *common.Work) error {
		_, err := wpInstance.ProduceFunc(ctx, func(context.Context, sqlstreams.Tx) (*common.Work, error) { return work, nil }, nil)
		return err
	})

	// the three arms share ONE caller count so the ratio is fair -- but N
	// callers blocked ~one commit each also CAPS arrival (Little's law), so
	// none of them is the batcher's ceiling. Saturate it: enough callers that
	// batches ride at Batch.MaxSize, which only the batched path can absorb
	// (a per-call arm would need a pool connection per caller).
	const satProducers, satMsgs = 800, 50
	saturated := timeArm(ctx, client, ds, "saturated", satProducers, satMsgs, func(wpInstance *sqlstreams.ProducerInstance[common.Work], work *common.Work) error {
		_, err := wpInstance.Produce(ctx, work, nil)
		return err
	})
	satRate := float64(satProducers*satMsgs) / saturated.Seconds()

	rate := func(elapsed time.Duration) float64 { return float64(total) / elapsed.Seconds() }
	fmt.Printf("  %-42s %8s %12s\n", fmt.Sprintf("arm (%d goroutines x %d msgs)", producers, msgs), "elapsed", "msgs/s")
	fmt.Printf("  %-42s %7.2fs %12.0f\n", "batched Produce", batched.Seconds(), rate(batched))
	fmt.Printf("  %-42s %7.2fs %12.0f\n", "per-call ProduceFunc", perCall.Seconds(), rate(perCall))
	fmt.Printf("  %-42s %7.2fs %12.0f\n", fmt.Sprintf("batched Produce, saturated (%d callers)", satProducers), saturated.Seconds(), satRate)
	fmt.Printf("  -> batched is %.1fx per-call at equal concurrency, %.1fx once callers\n", rate(batched)/rate(perCall), satRate/rate(perCall))
	fmt.Printf("     saturate the batch cap\n")
}

// timeArm registers its own stream, warms the pool untimed, then times the
// full concurrent run -- asserting afterward that every publish landed
// exactly once (throughput that loses messages doesn't count).
func timeArm(ctx context.Context, client *sqlstreams.Client, ds *iDatastore.PostgresDatastore, label string, producers, msgs int, produce func(wpInstance *sqlstreams.ProducerInstance[common.Work], work *common.Work) error) time.Duration {
	tp, client, cleanup := registerStream(ctx, client, "throughput."+label, largePartitionSize)
	defer cleanup()

	wpInstance, err := client.Stream[common.Work](tp.Name).Producer().Register(ctx, nil)
	common.Must(err)

	// warm pool connections so the first arm doesn't pay the dial cost
	warm := producers
	produceConcurrently(warm, 1, func(p, s int) error {
		work, err := common.NewWork(30, "warmup@example.com")
		if err != nil {
			return err
		}
		return produce(wpInstance, work)
	})

	start := time.Now()
	produceConcurrently(producers, msgs, func(p, s int) error {
		work, err := common.NewWork(30, "admin@example.com")
		if err != nil {
			return err
		}
		return produce(wpInstance, work)
	})
	elapsed := time.Since(start)

	assertCount(ctx, ds, fmt.Sprintf("%s.%s", ds.Schema, stream.MessageLogTable(tp.Id)), warm+producers*msgs, label+" arm landed every publish exactly once")
	return elapsed
}

// ---- helpers ----

// registerStream registers a stream unique to this e2e test and returns its cleanup.
func registerStream(ctx context.Context, client *sqlstreams.Client, label string, partitionSize int64) (*sqlstreams.Stream, *sqlstreams.Client, func()) {
	name := fmt.Sprintf("producerbatch.%s.%d", label, time.Now().UnixNano())
	tp, err := client.Stream[sqlstreams.RawPayload](name).Register(ctx, &sqlstreams.StreamConfig{PartitionSize: partitionSize})
	common.Must(err)
	return tp, client, func() {
		common.Must(client.Stream[sqlstreams.RawPayload](name).Destroy(ctx, &sqlstreams.DestroyOptions{Force: true}))
	}
}

// produceConcurrently fans producers goroutines x msgs calls each and dies on
// the first error any of them hit.
func produceConcurrently(producers, msgs int, produce func(p, s int) error) {
	errCh := make(chan error, producers*msgs)
	var wg sync.WaitGroup
	for p := range producers {
		wg.Go(func() {
			for s := range msgs {
				if err := produce(p, s); err != nil {
					errCh <- fmt.Errorf("producer %d seq %d: %w", p, s, err)
				}
			}
		})
	}
	wg.Wait()
	close(errCh)
	for err := range errCh {
		common.Die(err.Error())
	}
}

func assertCount(ctx context.Context, ds *iDatastore.PostgresDatastore, table string, want int, label string) {
	var count int
	common.Must(ds.Pool.QueryRow(ctx, fmt.Sprintf(`SELECT COUNT(*) FROM %s;`, table)).Scan(&count))
	if count != want {
		common.Die(fmt.Sprintf("%s: %s has %d rows, want %d", label, table, count, want))
	}
	fmt.Printf("  ✓ %s (%d)\n", label, count)
}

func step(s string) { fmt.Printf("\n--- %s ---\n", s) }

// rawPayload carries hand-written JSON bytes so the e2e test can produce a
// deliberately broken document; encoding/json validates MarshalJSON's
// output exactly as it does json.RawMessage's.
type rawPayload []byte

func (rawPayload) SchemaVersion() int { return 1 }

func (p rawPayload) MarshalJSON() ([]byte, error) { return p, nil }

func (p *rawPayload) UnmarshalJSON(data []byte) error {
	*p = append((*p)[:0], data...)
	return nil
}
